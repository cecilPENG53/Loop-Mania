from user import user_profile, user_profile_setname, user_profile_setemail, user_profile_sethandle #, user_profile_uploadphoto
from auth import auth_register
from data import user_data
import pytest
from error import InputError
from other import clear
from random import choice
import string
import re
import os
import shutil


'''
Function Name   Parameters         Return type      Exceptions

user_profile    (token, u_id)       { user }        InputError: when  
                                                    any of:User with
[For a valid user, returns information about        u_id is not a
user_id, email, first name, last name, and          valid user
handle]                                                            
                                                                       

user_profile_   (token, name_first,    {}           InputError when
setname        name_last)                           any of: name_first
                                                    (or name last) is 
[Update the authorised user's first and last        not between 1 and
name]                                               50 characters
                                                    inclusively in
                                                    length.
'''

@pytest.fixture
def user():
    '''
    take a valid registered user for test
    '''
    user = []

    email = 'anhehe119@gmail.com'
    password = 'HEHESUX364527YET'
    name_first = 'Hayden'
    name_last = 'Jacobs'     
    userValid = auth_register(email, password, name_first, name_last)

    user.append(userValid['u_id'])  #[0]
    user.append(userValid['token']) #[1]
    user.append(email)              #[2]
    user.append(name_first)         #[3]
    user.append(name_last)          #[4]

    for users in user_data:
        if user[0] == users['u_id']:
            user.append(users['handle_str']) #[5]
            '''users['profile_img_url'] = 'onlyfortest'
            user.append(users['profile_img_url'])  #[6]'''

    return user

@pytest.fixture
def name():
    '''
    take a random name (up to 51 chars) for test
    '''
    return ''.join([choice(string.ascii_letters) for i in range(51)])


def test_profile_valid(user):
 
    #test profile information with a valid user

    token = user[1]              #valid token
    u_id = user[0]               #valid user

    DATA = {
        'u_id': user[0],
        'email': user[2],
        'name_first': user[3],
        'name_last': user[4],
        'handle_str': user[5],
        #profile_img_url': user[6]
    }
    
    assert user_profile(token, u_id) == {'user': DATA}

    clear()

def test_profile_invalid_token(user):

    #test profile information with an invalid user (token)

    token = user[1]+user[1]      #invalid token
    u_id =  user[0]              #valid u_id

    with pytest.raises(InputError):
        assert user_profile(token, u_id)

    clear()

def test_profile_invalid_uid(user):

    #test profile information with an invalid user (u_id)

    token = user[1]              #valid token
    u_id =  user[0]+1            #invalid u_id

    with pytest.raises(InputError):
        assert user_profile(token, u_id)

    clear()

def test_profile_setname_valid(user):

    #valid names means they have length between 1 and 50
    #integers or special signs are allowed

    token = user[1]             #valid token
    
    first = 'Sos'               #valid first name
    last = 'Fighting'           #valid last name

    assert user_profile_setname(token, first, last) == {}

    first = 1
    last = 2

    assert user_profile_setname(token, first, last) == {}

    first = '%&^#^'
    last = '^%RHTG%'

    assert user_profile_setname(token, first, last) == {}

    clear()

def test_profile_setname_invalid(user, name):

    #invalid names means they are empty or over 50 chars

    token = user[1]             #valid token
    
    first = ''                  #invalid new first name (empty, len < 1)
    last = 'Fighting'            

    with pytest.raises(InputError):
        assert user_profile_setname(token, first, last)

    #first = ''                 #invalid new first name (empty, len < 1)
    last = ''                   #invalid new last name (empty, len < 1)

    with pytest.raises(InputError):
        assert user_profile_setname(token, first, last)

    first = 'Sos'
    #last = ''                  #invalid new last name (empty, len < 1)
    
    with pytest.raises(InputError):
        assert user_profile_setname(token, first, last)

    first = name                #invalid new first name (len > 50)                 
    last = 'Fighting'

    with pytest.raises(InputError):
        assert user_profile_setname(token, first, last)

    #first = name               #invalid new first name (len > 50)
    last = name                 #invalid new last name (len > 50)  

    with pytest.raises(InputError):
        assert user_profile_setname(token, first, last)

    first = 'Sos'  
    #last = name                #invalid new last name (len > 50)

    with pytest.raises(InputError):
        assert user_profile_setname(token, first, last)

    clear()

def test_profile_email_valid():
    clear()
    # test valid email format
    # build valid user_1
    email_1 = 'ankitrai326@gmail.com'
    user_1 = auth_register(email_1, '123456', 'Li', 'ming')
    assert user_profile_setemail(user_1['token'], 'my.ownsite@ourearth.org') == {}
    
    clear()
    # build valid user_2
    email_2 = 'my.ownsite@ourearth.org'
    user_2 = auth_register(email_2, '7654321', 'Ma', 'Zoe')
    assert user_profile_setemail(user_2['token'], 'ankitrai326@gmail.com') == {}
    
    
def test_profile_setemail_invalid_emailFormat():
    clear()
    # build a user for test
    user_test = auth_register('ankitrai326@gmail.com', '123456', 'Li', 'ming')
    
    # test invalid emails
    email_1 = 'ankitrai326.com'
    with pytest.raises(InputError):
        assert user_profile_setemail(user_test['token'], email_1)
    
    email_2 = '123'
    with pytest.raises(InputError):
        assert user_profile_setemail(user_test['token'], email_2)
    
    email_3 = '1531@'
    with pytest.raises(InputError):
        assert user_profile_setemail(user_test['token'], email_3)
        
def test_profile_setemail_invalid_duplicate():
    clear()
    # email already exist
    email_test = 'ankitrai326@gmail.com'
    user_test = auth_register(email_test, '123456', 'Li', 'ming')
    
    with pytest.raises(InputError):
        user_profile_setemail(user_test['token'], email_test)
    
def test_profile_sethandle_valid():
    clear()
    # build users for test
    user_1 = auth_register('ankitrai326@gmail.com', '123456', 'Li', 'ming')
    # name_first + name_last
    assert user_profile_sethandle(user_1['token'], 'mingli') == {}
    
    user_2 = auth_register('my.ownsite@ourearth.org', '7654321', 'Ma', 'Zoe')
    assert user_profile_sethandle(user_2['token'], 'zoema') == {}
    
def test_profile_sethandle_invalid_length():
    clear()
    # test for len < 3
    user_1 = auth_register('ankitrai326@gmail.com', '123456', 'Li', 'ming')
    with pytest.raises(InputError):
        assert user_profile_sethandle(user_1['token'], 'lm')
    # test for len >20
    user_2 = auth_register('my.ownsite@ourearth.org', '7654321', 'Ma', 'Zoe')
    with pytest.raises(InputError):
        assert user_profile_sethandle(user_2['token'], 'mamamamamamazoezoezoezoezoe')

def test_profile_sethandle_invalid_duplicate():
    clear()
    user = auth_register('ankitrai326@gmail.com', '123456', 'Li', 'ming')
    with pytest.raises(InputError):
        user_profile_sethandle(user['token'], 'liming')

'''
def test_profile_uploadphoto_valid(user):
    clear()

    token = user[1]              #valid token
    
    img_url = 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg'

    x_start = 300
    y_start = 0
    x_end = 600
    y_end = 300

    assert user_profile_uploadphoto(token, img_url, x_start, y_start, x_end, y_end) == {}

    clear()
    clearPhoto()

def test_test_profile_uploadphoto_invalid_type(user):

    token = user[1]              #valid token
    
    img_url = 'https://live.staticflickr.com/4620/27862477829_597a40656e_o.png'

    x_start = 300
    y_start = 0
    x_end = 600
    y_end = 300

    with pytest.raises(InputError):
        assert user_profile_uploadphoto(token, img_url, x_start, y_start, x_end, y_end)

    clear()
    clearPhoto()

def test_test_profile_uploadphoto_invalid_crop(user):

    token = user[1]                 #valid token
    
    img_url = 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg'

    #negative data

    x_start = -300 
    y_start = -1
    x_end = -600
    y_end = -300

    with pytest.raises(InputError):
        assert user_profile_uploadphoto(token, img_url, x_start, y_start, x_end, y_end)

    # start == max data (start >= end)

    x_start = 948
    y_start = 435
    x_end = 600
    y_end = 300

    with pytest.raises(InputError):
        assert user_profile_uploadphoto(token, img_url, x_start, y_start, x_end, y_end)

    # > max data

    x_start = 1000                  
    y_start = 800                   
    x_end = 1000                    
    y_end = 800                     

    with pytest.raises(InputError):
        assert user_profile_uploadphoto(token, img_url, x_start, y_start, x_end, y_end)

    clear()
    clearPhoto()
'''
def clearPhoto():
    
    curr_dir = os.getcwd()
    photo_dir = os.path.join(curr_dir, r'photo')
    
    if os.path.exists(photo_dir):
        shutil.rmtree(photo_dir)