import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from other import clear
from channels_http_test import striphtml

'''
Function Name      HTTP Method   Parameters    Return type  Exceptions

channel_addowner   POST          (token,       {}           InputError:
[Make user with                  channel_id,                Invalid Channel ID;
user id u_id an                  u_id)                      uid is already an
owner of this                                               owner of channel
channel]                                                    AccessError:
                                                            Invalid authorised
                                                            user (not an owner
                                                            of the flockr, or
                                                            this channel).
                                                
channel_removeowner POST        (token,       {}            InputError:
[Remove user                    channel_id,                 Invalid Channel ID;
with user id                    u_id)                       uid is not an
u_id an owner                                               owner of channel.
of this channel]                                            AccessError:
                                                            Invalid authorised
                                                            user (not an owner
                                                            of the flockr, or
                                                            this channel).
'''

# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

# To test valid add/remove owner,
# valid users (including authorised & moved)
# and valid channel are needed.

@pytest.fixture
def values(url):

    values = []

    #valid authorised user

    IN1 = {
        'email': 'addremovemore@123.com',
        'password': '367SYGTDJYS637',
        'name_first':'Nancy',
        'name_last': 'Hu'
    }

    userAuthorised = requests.post(f'{url}/auth/register', json=IN1)
    userInfo1 = userAuthorised.json()
    
    values.append(userInfo1['token'])    #[0]
    values.append(userInfo1['u_id'])     #[1]

    #valid moved user (not a member of channel)

    IN2 = {
        'email': 'addremovemore@789.com',
        'password': 'dshdJFW37qehd2d',
        'name_first': 'Lucy',
        'name_last': 'King'
    }

    userMoved = requests.post(f'{url}/auth/register', json=IN2)
    userInfo2 = userMoved.json()
    
    values.append(userInfo2['token'])    #[2]
    values.append(userInfo2['u_id'])     #[3]

    #valid channel_id, created by authorised user

    DATA = {
        'token': userInfo1['token'],
        'name': 'Second Channel',
        'is_public': True
    }

    channelCreated = requests.post(f'{url}/channels/create', json=DATA)
    channelData = channelCreated.json()

    values.append(channelData['channel_id'])    #[4]

    return values


def test_http_channel_addremove_valid(url, values):

    IN = {
        'token': values[0],         #valid authorised user
        'u_id': values[3],          #valid moved user (not a member of channel)
        'channel_id': values[4]     #valid channel
    }

    pass_message(url, IN)

def test_http_channel_add_invalid(url, values):

    IN = {
        'token': values[2],         #invalid owner of channel, moved user's token
        'u_id': values[3],          #valid moved user's id
        'channel_id': values[4]     #valid channel
    }

    mesg = "You are not an owner of this channel"
    error_message(url, 1, IN, mesg)

    IN = {
        'token': values[0]+values[2],#invalid owner of flockr
        'u_id': values[3],           #valid moved user
        'channel_id': values[4]      #valid channel
    }

    mesg = "You are not a user of flockr"
    error_message(url, 1, IN, mesg)

    IN = {
        'token': values[0],          #valid authorised user
        'u_id': values[3],           #valid moved user
        'channel_id': values[4]+42   #invalid channel, not exist
    }

    mesg = "This channel is not exist"
    error_message(url, 1, IN, mesg)

    IN = {
        'token': values[0],          #valid authorised user
        'u_id': values[0]+values[2], #invalid moved user, not user of flockr
        'channel_id': values[4]      #valid channel
    }

    mesg = "This id is not a user of flockr"
    error_message(url, 1, IN, mesg)

    IN = {
        'token': values[0],          #valid authorised user
        'u_id': values[1],           #invalid moved user, authorised user's uid
        'channel_id': values[4]      #valid channel
    }

    mesg = "This user is already an owner of the channel"
    error_message(url, 1, IN, mesg)

def test_http_channel_remove_invalid(url, values):

    IN = {
        'token': values[2],         #invalid owner of channel, moved user's token
        'u_id': values[1],          #valid owner, authorised user's id
        'channel_id': values[4]     #valid channel
    }

    mesg = "You are not an owner of this channel"
    error_message(url, 2, IN, mesg)

    IN = {
        'token': values[0]+values[2],#invalid owner of flockr
        'u_id': values[1],           #valid owner, authorised user's id
        'channel_id': values[4]      #valid channel
    }

    mesg = "You are not a user of flockr"
    error_message(url, 2, IN, mesg)

    IN = {
        'token': values[0],          #valid authorised user
        'u_id': values[1],           #valid owner, authorised user's id
        'channel_id': values[4]+42   #invalid channel, not exist
    }

    mesg = "This channel is not exist"
    error_message(url, 2, IN, mesg)

    IN = {
        'token': values[0],          #valid authorised user
        'u_id': values[2]+values[0], #invalid moved user, not user of flockr
        'channel_id': values[4]      #valid channel
    }

    mesg = "This id is not a user of flockr"
    error_message(url, 2, IN, mesg)

    IN = {
        'token': values[0],          #valid authorised user
        'u_id': values[3],           #invalid moved user, not added yet
        'channel_id': values[4]      #valid channel
    }

    mesg = "This user is not an owner of the channel yet"
    error_message(url, 2, IN, mesg)


def pass_message(url, info):
    
    resp1 = requests.post(url + "/channel/addowner", json=info)
    #assert json.loads(resp1.text) == {}
    assert resp1.json() == {}

    resp2 = requests.post(url + "/channel/removeowner", json=info)
    #assert json.loads(resp2.text) == {}
    assert resp2.json() == {}

    clear()

def error_message(url, kind, info, mesg):

    if kind == 1:   #add owner
        resp = requests.post(url + "/channel/addowner", json=info)
    else:           #remove owner
        resp = requests.post(url + "/channel/removeowner", json=info)

    ##test method from channels_http_test
    # assert error code is raised
    assert resp.status_code == 400
    res = resp.json()
    
    # assert error message as expected
    msg = res['message']
    assert striphtml(msg) == mesg

    clear()
