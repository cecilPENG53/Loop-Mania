'''
module that contains other functions that do not belong in a particular module
'''

import data
from error import InputError, AccessError
from datetime import datetime as date, timedelta, timezone


def clear():
    '''
    function to clear all existing data
    '''

    data.user_data.clear()
    data.channel_data.clear()
    data.valid_token.clear()

    return {}

def users_all(token):
    '''
    function that returns all users in database
    given token that is checked for validity
    '''

    # token check
    invalid_token = True

    if token in data.valid_token:
        invalid_token = False

    # invalid token raises an error
    if invalid_token is True:
        raise AccessError('Invalid token')

    # loops through data of all channels created
    # append channel ids and names to list
    result = {
        'users': []
    }

    for user in data.user_data:
        if 'profile_img_url' in user:
            result['users'].append(
                {
                    'u_id': user['u_id'],
                    'email': user['email'],
                    'name_first': user['name_first'],
                    'name_last': user['name_last'],
                    'handle_str': user['handle_str'],
                    'profile_img_url': user['profile_img_url']
                },
            )
        else:
            result['users'].append(
                {
                    'u_id': user['u_id'],
                    'email': user['email'],
                    'name_first': user['name_first'],
                    'name_last': user['name_last'],
                    'handle_str': user['handle_str']
                },
            )


    return result

def admin_userpermission_change(token, u_id, permission_id):
    '''
    function that changes a user's permission
    permission id:
        id 1: flockr owner
        id 2: normal user
    '''

    # permission_id check
    if permission_id not in [1, 2]:
        raise InputError('Invalid permission type')

    # token & permission level check
    invalid_token = True
    insufficient_permission = True

    for user in data.user_data:
        if user['token'] is token:
            invalid_token = False
            if user['permission_id'] == 1:
                insufficient_permission = False

    # raise error if token is invalid
    if invalid_token is True:
        raise AccessError('Invalid token')

    # raise error if token lacks suffice permission
    if insufficient_permission is True:
        raise AccessError('User does not have owner permissions')

    # u_id check
    invalid_user = True

    # changes u_id permission if u_id exists and change invalid_user to False
    for user in data.user_data:
        if user['u_id'] is u_id:
            invalid_user = False
            user['permission_id'] = permission_id
            return {}

    if invalid_user is True:
        raise InputError('Invalid user')
    return {}
def search(token, query_str):
    '''
    function that searches a given string and returns
    relevant messages containing said string
    '''

    if query_str == '':
        return {'messages': []}

    new = []
    #user_id = getUserId(token)
    for  message_info in data.channel_data:
        for message_list in message_info['messages']:
            if (query_str in  message_list['message']):
                return_message = {
                    'message_id' :  message_list['message_id'],
                    'user_id' :   message_list['u_id'],
                    'message' :  message_list['message'],
                    'time_created' :  message_list['time_created']
                }
                new.append(return_message)
    return {'messages' : new}

