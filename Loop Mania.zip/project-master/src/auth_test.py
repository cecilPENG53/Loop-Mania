import auth
import data 
import other
import echo
import pytest
from error import InputError
import jwt


SECRET = 'thu13orangeteam1'

# test file for functions in auth.py
'''
auth_login
(email, password)
{ u_id, token }

InputError when any of:
1. Email entered is not a valid email
2. Email entered does not belong to a user
3. Password is not correct
'''
# this is test for normal login
# when users register first and give there email and passward
# they are suppose to login successfully
def test_auth_login():
    user_info = auth.auth_register('goodemail@gmail.com', '123456789', 'hayden', 'smith')
    assert auth.auth_login('goodemail@gmail.com', '123456789') == user_info
    other.clear()

# this is test for email entered is not a valid email
# we assume that the email which user entered contains uncorrect character
# email they entered should like sampledata@abc.com
# otherwise they are not able to login
def test_auth_login_invalidEmail():
    auth.auth_register("minglang@gmail.com", "12345678", "minglang", "xie")
    with pytest.raises(InputError):
        auth.auth_login("minglang_gmail.com", "12345678")
    other.clear()

# this is test for email entered does not belong to a user
# we assume that the email which user entered is not the one they registerd before
# since the email they entered is wrong, users are not able to login
def test_auth_login_notBelongToUser():
    auth.auth_register("minglang@gmail.com", "12345678", "minglang", "xie")
    with pytest.raises(InputError):
        auth.auth_login("w17a.credible4@gmail.com", "12345678")
    other.clear()

# this is test for password is not correct
# we assume that the password that user entered is not the one they registerd before
# since teh 
def test_auth_login_passwordIncorrect(): 
    auth.auth_register("minglang@gmail.com", "12345678", "minglang", "xie")
    with pytest.raises(InputError):
        auth.auth_login("minglang@gmail.com", "1234567890")
    other.clear()


'''
auth_logout
(token)
{ is_success }
N/A
'''
# this is test for users can logout successfully
# we assume users register first and the system will login automatically
# when usters logout, it returns true
def test_auth_logout_ture():
    user_info = auth.auth_register('hayden@gmail.com', '123456', 'hayden', 'smith')

    assert auth.auth_logout(user_info['token']) == {'is_success': True}
    other.clear()

# this is test for users can not logout successfully
# we assume users register first and the system will login automatically
# then users logout, it returns true
# however, if users logout again, it returns false
# since the token has alreadly been invalid
def test_auth_logout_false():
    # login, logout, then logout again
    user_info = auth.auth_register('hayden@gmail.com', '123456', 'haden', 'smith')
    assert auth.auth_logout(user_info['token']) == {'is_success': True}
    assert auth.auth_logout(user_info['token']) == {'is_success': False}
    other.clear()



'''
auth_register
(email, password, name_first, name_last)
{ u_id, token }

InputError when any of:
1. Email entered is not a valid email
2. Email address is already being used by another user
3. Password entered is less than 6 characters long
4. name_first not is between 1 and 50 characters in length
5. name_last is not between 1 and 50 characters in length
'''
# this is test for normal register
# when the first user registered, 
# we create a new account for them and return a new token for authentication in their session
def test_auth_register1():
    user_info = auth.auth_register("minglang@gmail.com", "12345678", "minglang", "xie")

    # generate token
    token = str(jwt.encode({'email': 'minglang@gmail.com'}, SECRET, algorithm='HS256'))

    assert user_info == {'u_id': len(data.user_data) - 1, 'token': token}
    assert auth.auth_login("minglang@gmail.com", "12345678") == user_info

# this is test for normal register too
# when the second user registered, 
# the u_id given should be one more the the first user's uid
def test_auth_register2():
    # create another user to see if the user successful joined into list
    user_info2 = auth.auth_register("wores@gmail.com", "abcd1234", "Yun", "Li")
    
    # generate token
    token = str(jwt.encode({'email': 'wores@gmail.com'}, SECRET, algorithm='HS256'))

    assert user_info2 == {'u_id': len(data.user_data) - 1, 'token': token}
    assert auth.auth_login("wores@gmail.com", "abcd1234") == user_info2

# this is test for email entered is not a valid email
# we assume the email that user regiter for is not like the style of sampledata@abc.com
# since the email enterd is invalid, they are not able to regeiter
def test_auth_register_invalidEmail():
    with pytest.raises(InputError):
        auth.auth_register('asdadsad', '123456','gaoping','zhang')
    other.clear()


# this is test for email address is already being used by another user
# since the email is already been used, this register is invalid
def test_auth_register_emailBeUsed():
    auth.auth_register("minglang@gmail.com", "12345678", "minglang", "xie")
    with pytest.raises(InputError):
        auth.auth_register("minglang@gmail.com", "23456456", "xie", "minglang")
    other.clear()


# this is test for password entered is less than 6 characters long
# since the password they entered is not what we expect
# this register is invalid and will get inputerror
def test_auth_register_invalidPassword():
    with pytest.raises(InputError):
        auth.auth_register("anbo@gmail.com", "12345", "anbo", "xie")
    other.clear()


# this is test for name_first is not between 1 and 50 characters in length
# since the first name they entered is not what we expect
# this register is invalid and will get inputerror
def test_auth_register_incorrectFirstName():
    with pytest.raises(InputError):
        auth.auth_register("babala@gmail.com", "12345678", "Y" * 51, "Li")
    other.clear()


# this is test for name_last is not between 1 and 50 characters in length
# since the last name they entered is not what we expect
# this register is invalid and will get inputerror
def test_auth_register_incorrectLastName():
    other.clear()

    with pytest.raises(InputError):
        auth.auth_register("balala@gmail.com", "12345678", "Yun", "L" * 51)


# interation 3

# this is test for passwordreset/request and reset
# Given a reset code for a user, 
# set that user's new password to the password provided
# unless it raise the error
def test_auth_passwordreset_reset():
    other.clear()

    user_info = auth.auth_register("minglang@gmail.com", "12345678", "minglang", "xie")
    auth.auth_passwordreset_request("minglang@gmail.com")

    for user in data.user_data:
        reset_code = user['reset_code']

    auth.auth_passwordreset_reset(reset_code, '87654321')
    assert auth.auth_login("minglang@gmail.com", "87654321") == user_info

# this is test for passwordreset/reset
# error is raised since reset_code is not valid reset code
def test_auth_passwordreset_reset_invalidResetCode():
    other.clear()

    auth.auth_register('jankie@gmail.com', '123456','gaoping','zhang')
    auth.auth_passwordreset_request('jankie@gmail.com')

    with pytest.raises(InputError):
        auth.auth_passwordreset_reset('123', '123456')

# this is test for passwordreset/reset
# error is raised since password entered is not valid
def test_auth_passwordreset_reset_invalidNewPassword():
    other.clear()

    auth.auth_register('jankie@gmail.com', '123456','gaoping','zhang')
    auth.auth_passwordreset_request('jankie@gmail.com')

    for user in data.user_data:
        reset_code = user['reset_code']

    with pytest.raises(InputError):
        auth.auth_passwordreset_reset(reset_code, '1')
