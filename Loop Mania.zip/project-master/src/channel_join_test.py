from data import *
from channel import channel_join
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
from datetime import datetime as date
from helper_function import find_channel

# InputError when any of:Channel ID is not a valid channel
# AccessError whenAuthorised user is not a member of channel with channel_id
# get user from token,
# is channel valid,
# is the channel private (is the user admin)
# if sucess append the user to all_users list

# channel_join(token, channel_id)
def test_channel_join():
# reset dsta
    clear()
    
    # bulid two user
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')
    
    # create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
    channels_create(user_2['token'], 'channel_2', 'false')
    
    # # test successful situation of initial
    assert channel_join(user_2['token'], 1) == {}
    curr_channel = find_channel(1)
    assert len(curr_channel['users']) == 2

    # # test failure situation of initial
    # # Channel ID is not a valid channel
    with pytest.raises(InputError):
        channel_join(user_1['token'], 3)
    
    with pytest.raises(InputError):
        channel_join(user_2['token'], 3)

    # # pravite channel
    with pytest.raises(AccessError):
        channel_join(user_1['token'], 2)

