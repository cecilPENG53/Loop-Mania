import data 
import other
from error import InputError
from helper_function import getUserId
import jwt
from hashlib import sha256
import random
import string 

# re module provides support 
# for regular expressions 
import re 

SECRET = 'thu13orangeteam1'

'''
Given a registered users' email and password and generates a valid token for
the user to remain authenticated
'''
def auth_login(email, password):
    # check whether email is valid or not
    regex = '^[a-z0-9]+[\\._]?[a-z0-9]+[@]\\w+[.]\\w{2,3}$'

    if not re.search(regex, email):
        raise InputError("Email entered is not a valid email")

    # checking if this email has been registered
    found = False
    for user in data.user_data:
        if user['email'] == str(email):
            found = True
            break
    if not found:
        raise InputError("Email entered doesn't belong to a user")

    # generate token
    token = str(jwt.encode({'email': email}, SECRET, algorithm='HS256'))

    # logging in
    for user in data.user_data:
        if user['email'] == email:
            if user['password'] == password:
                data.valid_token.append(token)
                return {
                    'u_id': user['u_id'],
                    'token': token
                }
            else:
                raise InputError("Username or password incorrect")

'''
Given an active token, invalidates the taken to log the user out. If a valid
token is given, and the user is successfully logged out, it returns true,
otherwise false.
'''
def auth_logout(token):
    # token check
    u_id = getUserId(token)

    for user in data.user_data:
        if user['u_id'] == u_id:
            user['token'] = {}
            data.valid_token.remove(token)
            return {'is_success': True}
    return {'is_success': False}


'''
Given a user's first and last name, email address, and password, create a new
account for them and return a new token for authentication in their session. A
handle is generated that is the concatentation of a lowercase-only first name and
last name. If the concatenation is longer than 20 characters, it is cutoff at 20
characters. If the handle is already taken, you may modify the handle in any way
you see fit to make it unique.
'''
def auth_register(email, password, name_first, name_last):
    # Make a regular expression 
    # for validating an Email 
    regex = '^[a-z0-9]+[\\._]?[a-z0-9]+[@]\\w+[.]\\w{2,3}$'

    # error checking
    # check email entered is not a valid email
    if not (re.search(regex,email)):
        raise InputError("Invalid Email")

    # check whether email address is already being used by another user
    for user in data.user_data:
        if user['email'] == email:
            raise InputError("Email address is already used bt another user.")

    # check the length of password is less than 6 characters long
    if len(password) < 6:
        raise InputError("Password should be at least 6 characters long")

    # check the length of password is between 1 and 50 characters
    if len(name_first) > 50 or len(name_first) < 1:
        raise InputError("Firstname is needed between 1 and 50 characters.")

    # check the length of password is between 1 and 50 characters
    if len(name_last) > 50 or len(name_last) < 1:
        raise InputError("Lastname is needed between 1 and 50 characters.")

    # calculate and assign u_id
    new_u_id = len(data.user_data)

    # generate token
    token = str(jwt.encode({'email': email}, SECRET, algorithm='HS256'))
    permission_id = 2
    if new_u_id == 0:
        permission_id = 1

    handle = (name_first + name_last).lower()
    if len(handle) < 3:
        handle = str(new_u_id) + handle
        handle = handle[:(20 - len(str(new_u_id)))] + str(new_u_id)

    for user in data.user_data:
        if user['handle_str'] == handle[:20]:
            handle = str(new_u_id) + handle
            handle = handle[:(20 - len(str(new_u_id)))] + str(new_u_id)
            break

    data.user_data.append(
        {
        'u_id': new_u_id,
        'email': email,
        'password': password,
        'name_first': name_first,
        'name_last': name_last,
        'handle_str': str(handle[:20]),
        'permission_id': permission_id,
        'reset_code': None,
        'channels': [],
        'token': token
        }
    )

    # generate token
    data.valid_token.append(token)

    return {'u_id': new_u_id, 'token': token}


# Given an email address, if the user is a registered user, send's them a an email
# containing a specific secret code, that when entered in auth_passwordreset_reset,
# shows that the user trying to reset the password is the one who got sent this email.
def auth_passwordreset_request(email):
    reset_code = None
    
    for user in data.user_data:
        if user['email'] == email:
            N = 200
            reset_code = "".join(random.choice(string.ascii_uppercase + string.digits) for _ in range(N))
            user['reset_code'] = reset_code
    return {}

# Given a reset code for a user, set that user's new password to the password provided
# ValueError when:
# reset_code is not valid reset code
# password entered is not valid
def auth_passwordreset_reset(reset_code, new_password):
    #incorrect password
    if len(new_password) in range(6):
        raise InputError("Password entered is not a valid password")

    valid_code = True
    for user in data.user_data:
        if user['reset_code'] == reset_code:
            valid_code = False
            user['password'] = new_password
            user['reset_code'] = None

    if valid_code:
        raise InputError("reset_code is not a valid reset code")
    return {}