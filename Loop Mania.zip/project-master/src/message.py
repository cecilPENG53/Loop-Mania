import data 
import other
from error import InputError, AccessError
from helper_function import add_message, getUserId, find_channel, is_InChannel, generateMsgId, find_message, findChannelFromMsgId, is_InOwnerChannel
from datetime import datetime as date, timedelta, timezone
import datetime

def message_send(token, channel_id, message):
    """
    Send a message from authorised_user to the channel specified
    by channel_id
    """
    user_id = getUserId(token)

    if len(message) > 1000:
        raise InputError("Message is more than 1000 characters")
    
    curr_channel = find_channel(channel_id)
    result = is_InChannel(curr_channel, user_id)

    if result == False:
        raise AccessError("the authorised user has not joined the channel they are trying to post to")
    
    #assume the message_id should unique id
    message_id = generateMsgId()
    time = date.utcnow()
    #time = time.strftime("%y-%m-%d-%H:%M:%S")
    time = time.replace(tzinfo=timezone.utc).timestamp()
    curr_channel['messages'].append({
        'message_id' : message_id,
        'u_id': user_id,
        'message': message,
        'time_created': time,
        'reacts':[{'react_id':1, 'u_ids':[]}],
        'is_pinned': False
    })

    return {
        'message_id': message_id,
    }

def message_remove(token, message_id):
    """
    Given a message_id for a message, this message is removed from the channel
    """
    user_id = getUserId(token)
    delet_message = find_message(message_id)

    if delet_message == {}:
        raise InputError("Message (based on ID) no longer exists")

    #get the channel details from message_id
    curr_channel = findChannelFromMsgId(message_id)

    is_authorUser = False
    if delet_message['u_id'] == user_id:
        is_authorUser = True
   
    is_ownerUser = is_InOwnerChannel(curr_channel, user_id)
 
    if is_authorUser== False and is_ownerUser == False:
        raise AccessError("Message with message_id wasn't sent by the authorised user making this request or The authorised user is not an owner of this channel or the flockr")

    #delete message
    curr_channel['messages'].remove(delet_message)

    return {
    }
# message_send('sampledata@abc.com', 1, "hello")
# message_remove('sampledata@abc.com', 1)


def message_edit(token, message_id, message):
    '''
    data = other.getData()
    user_dict = data['users'][getUserFromToken(token)]
    msg_dict = data['messages'][find_message(message_id)]
    '''
    user_id = getUserId(token)
    edit_message = find_message(message_id)

    if message == {}:
        raise InputError("Message is deleted")

    #get the channel details from message_id
    curr_channel = findChannelFromMsgId(message_id)

    is_authorUser = False
    if edit_message['u_id'] == user_id:
        is_authorUser = True
   
    is_ownerUser = is_InOwnerChannel(curr_channel, user_id)
 
    if is_authorUser== False and is_ownerUser == False:
        raise AccessError("Unauthorised user making edit request")

    # edit message
    time = date.utcnow()
    time = time.replace(tzinfo=timezone.utc).timestamp()
    curr_channel['messages'].append(
            {   'message_id': edit_message['message_id'],
                'u_id': edit_message['u_id'],
                'messages': message,
                'time_created':time,
                'reacts':[{'react_id':1, 'u_ids':[]}],
                'is_pinned': False
            }
        )
    curr_channel['messages'].remove(edit_message)

    return {}

def message_sendlater(token, channel_id, message, time_sent):
    """
    Send a message from authorised_user to the channel specified by 
    channel_id automatically at a specified time in the future
    """
    user_id = getUserId(token)

    curr_channel= find_channel(channel_id)
    if curr_channel == False:
        raise InputError("Channel ID is not a valid channel")

    if len(message) > 1000:
        raise InputError("Message is more than 1000 characters")

    message_id = generateMsgId()

    now = date.utcnow()
    if type(time_sent) != date:
        time_sent = date.utcfromtimestamp(int(time_sent))
    if now > time_sent:
        raise InputError("Time sent is a time in the past")
    time_sent = time_sent.replace(tzinfo=timezone.utc).timestamp() 
    # now = now.strftime("%y-%m-%d-%H:%M:%S")
    # if type(time_sent) == date:
    #     time_sent = time_sent.strftime("%y-%m-%d-%H:%M:%S")
    # if now > time_sent:
    #     raise InputError("Time sent is a time in the past")

    result = is_InChannel(curr_channel, user_id)
    
    if result == False:
        raise AccessError("the authorised user has not joined the channel they are trying to post to")

    #update message
    curr_channel['messages'].append({
        'message_id' : message_id,
        'u_id': user_id,
        'message': message,
        'time_created': time_sent,
        'reacts':[{'react_id':1, 'u_ids':[]}],
        'is_pinned': False
    })
    return {'message_id':message_id}


def message_react(token, message_id, react_id):
    """
    Given a message within a channel the authorised user is part of, add a "react" to that particular message
    """
    user_id = getUserId(token)

    #message_id is not a valid message within a channel that the authorised user has joined
    curr_channel = findChannelFromMsgId(message_id)
    result = is_InChannel(curr_channel, user_id)
    if result == False:
        raise InputError("message_id is not a valid message within a channel that the authorised user has joined")

    #
    if react_id != 1:
        raise InputError("react_id is not a valid React ID. The only valid react ID the frontend has is 1")

    message_list = find_message(message_id)
    react_list = message_list['reacts']
    uid_list = react_list[0]['u_ids']

    if user_id in uid_list:
        raise InputError("Message with ID message_id already contains an active React with ID react_id from the authorised user")
    
    #add user who react in u_ids 
    uid_list.append(user_id)
    
    return {}

def message_unreact(token, message_id, react_id):
    """
    Given a message within a channel the authorised user is part of, add a "react" to that particular message
    """
    user_id = getUserId(token)

    #message_id is not a valid message within a channel that the authorised user has joined
    curr_channel = findChannelFromMsgId(message_id)
    result = is_InChannel(curr_channel, user_id)
    if result == False:
        raise InputError("message_id is not a valid message within a channel that the authorised user has joined")

    #
    if react_id != 1:
        raise InputError("react_id is not a valid React ID")

    message_list = find_message(message_id)
    react_list = message_list['reacts']
    uid_list = react_list[0]['u_ids']

    if user_id not in uid_list:
        raise InputError("Message with ID message_id does not contain an active React with ID react_id")
    
    #remove user who react in u_ids 
    uid_list.remove(user_id)
    
    return {}
def message_pin(token, message_id):
    # Given a message within a channel, mark it as "pinned" to be given special display treatment by the frontend
    user_id = getUserId(token)
    # InputError
    # message_id is not a valid message
    message_list = find_message(message_id)
    if message_list == {}:
        raise InputError("Message_id is not a valid message")
    
    # Message with ID message_id is already pinned
    #message_list = find_message(message_id)
    if message_list['is_pinned'] is True:
        raise InputError("Message with ID message_id is already pinned")
        
    # AccessError
    # The authorised user is not a member of the channel that the message is within
    curr_channel = findChannelFromMsgId(message_id)
    result = is_InChannel(curr_channel, user_id)
    if result == False:
        raise AccessError("The authorised user is not a member of the channel that the message is within")
    
    # The authorised user is not an owner
    is_admin = is_InOwnerChannel(curr_channel, user_id)
    if is_admin is False:
        raise AccessError("The authorised user is not an owner")
    
    message_list['is_pinned'] = True
    return {}
def message_unpin(token, message_id):
    # Given a message within a channel, remove it's mark as unpinned
    user_id = getUserId(token)
    # InputError
    # message_id is not a valid message
    message_list = find_message(message_id)
    if message_list == {}:
        raise InputError("Message_id is not a valid message")
    # Message with ID message_id is already unpinned
    #message_list = find_message(message_id)
    if message_list['is_pinned'] is False:
        raise InputError("Message with ID message_id is already unpinned")
        
    # AccessError
    # The authorised user is not a member of the channel that the message is within
    curr_channel = findChannelFromMsgId(message_id)
    result = is_InChannel(curr_channel, user_id)
    if result == False:
        raise AccessError("The authorised user is not a member of the channel that the message is within")
    # The authorised user is not an owner
    is_admin = is_InOwnerChannel(curr_channel, user_id)
    if is_admin is False:
        raise AccessError("The authorised user is not an owner")
        
    message_list['is_pinned'] = False
    return {}
