from data import * 
from channel import channel_invite, channel_details, channel_messages
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear, search
from datetime import datetime as date
from helper_function import add_message
from message import message_send, message_edit

def test_search():
    clear()

    user_info1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    channels_create(user_info1['token'], 'channel_1', 'true')
    message_send(user_info1['token'], 1, "first message")
    message_send(user_info1['token'], 1, "second message")
    
    messages = search(user_info1['token'], 'mess')
    assert len(messages['messages']) == 2
    
    messages = search(user_info1['token'], 'p')
    assert len(messages['messages']) == 0

    messages = search(user_info1['token'], '')
    assert len(messages['messages']) == 0

    messages = search(user_info1['token'], 'second')
    assert len(messages['messages']) == 1
    
    clear()