'''
test file for functions in channels.py
'''

import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import pytest
import requests
import json

@pytest.fixture
def url():
    ''' fixture to get URL of server '''

    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

def test_http_channels_list(url):
    '''
    http test for channels_list
    expect return of list of channels that user is in
    '''

    # clear existing data
    res = requests.delete(f'{url}/clear')

    # register two user for validated tokens
    res = requests.post(f'{url}/auth/register', json={
        'email': 'listall_private@test.com',
        'password': 'T3stingP4ssw0rd',
        'name_first': 'Private Channel',
        'name_last': 'Tester'
    })

    user_1 = res.json()

    res = requests.post(f'{url}/auth/register', json={
        'email': 'listall_public@test.com',
        'password': 'T3stingP4ssw0rd',
        'name_first': 'Public Channel',
        'name_last': 'Tester'
    })

    user_2 = res.json()

    # create one private channel and one public channel using validated tokens
    res = requests.post(f'{url}/channels/create', json={
        'token': user_1['token'],
        "name": 'Private Channel',
        "is_public": False
    })

    pri_channel = res.json()

    res = requests.post(f'{url}/channels/create', json={
        'token': user_2['token'],
        "name": 'Public Channel',
        "is_public": True
    })

    # use user_1 token to obtain list of channel user_1 is in
    res = requests.get(f'{url}/channels/list', params={
        'token': user_1['token']
    })
   
    list_detail = res.json()

    # establish expected result
    expected_result = {'channels': [{
        'channel_id': pri_channel['channel_id'],
        'name': 'Private Channel',
    }]}

    # assert json.loads(res.text) == expected_result
    assert list_detail == expected_result

def test_http_channels_list_invalid_token(url):
    '''
    token error http test for channels_list
    expect error raised
    '''

    # clear existing data
    res = requests.delete(f'{url}/clear')

    # request list function with invalid token
    res = requests.get(f'{url}/channels/list', json={
        'token': -1
    })

    # assert error code 400 is raised
    assert res.status_code == 400
    res = res.json()
    res = res['message']

    # assert error message is per expected
    expected_message = 'Invalid token'
    assert striphtml(res) == expected_message

def test_http_channels_listall(url):
    '''
    http test for channels_listall
    expect return of list of all channels
    '''

    # clear existing data
    res = requests.delete(f'{url}/clear')

    # register two user for validated tokens
    res = requests.post(f'{url}/auth/register', json={
        'email': 'listall_private@test.com',
        'password': 'T3stingP4ssw0rd',
        'name_first': 'Private Channel',
        'name_last': 'Tester'
    })

    user_1 = res.json()

    res = requests.post(f'{url}/auth/register', json={
        'email': 'listall_public@test.com',
        'password': 'T3stingP4ssw0rd',
        'name_first': 'Public Channel',
        'name_last': 'Tester'
    })

    user_2 = res.json()

    # create one private channel and one public channel using validated tokens
    res = requests.post(f'{url}/channels/create', json={
        'token': user_1['token'],
        "name": 'Private Channel',
        "is_public": False
    })

    pri_channel = res.json()

    res = requests.post(f'{url}/channels/create', json={
        'token': user_2['token'],
        "name": 'Public Channel',
        "is_public": False
    })

    pub_channel = res.json()

    # use user_2 token to obtain list of all channels
    # res = requests.get(f'{url}/channels/listall', json={
    #     'token': user_2['token']
    # })
    res = requests.get(f"{url}/channels/listall?token="+ user_2['token'])

    listall_detail = res.json()

    # establish expected result
    expected_result = {'channels': [{
        'channel_id': pri_channel['channel_id'],
        'name': 'Private Channel',
    }, {
        'channel_id': pub_channel['channel_id'],
        'name': 'Public Channel',
    }, ]}

    assert listall_detail == expected_result

def test_http_channels_listall_invalid_token(url):
    '''
    token error http test for channels_listall
    expect error raised
    '''

    # clear existing data
    res = requests.delete(f'{url}/clear')

    # request listall function with invalid token
    res = requests.get(f'{url}/channels/listall', json={
        'token': -1
    })

    # assert error code 400 is raised
    assert res.status_code == 400
    res = res.json()
    res = res['message']

    # assert error message is per expected
    expected_message = 'Invalid token'
    assert striphtml(res) == expected_message

def test_http_channels_create(url):
    '''
    http test for channels_create
    expect return of channel_id
    '''

    # clear existing data
    res = requests.delete(f'{url}/clear')

    # register a user for validated token
    res = requests.post(f'{url}/auth/register', json={
        'email': 'channelcreation@test.com',
        'password': 'T3stingP4ssw0rd',
        'name_first': 'Channel Creation',
        'name_last': 'Tester'
    })

    user_detail = res.json()

    # create channel using validated token
    res = requests.post(f'{url}/channels/create', json={
        'token': user_detail['token'],
        'name': 'Regular Channel',
        'is_public': True
    })

    channel_detail = res.json()

    # check output structure
    assert channel_detail == {'channel_id': channel_detail['channel_id']}

    # obtain list of all channels for checking
    res = requests.get(f'{url}/channels/listall', params={
        'token': user_detail['token']
    })

    listall_detail = json.loads(res.text)

    # checks that returned channel_id exists in data retrieved using listall
    channel_id_exists = False

    for channel in listall_detail['channels']:
        if channel['channel_id'] == channel_detail['channel_id']:
            channel_id_exists = True

    assert channel_id_exists is True

def test_http_channels_create_invalid_token(url):
    '''
    token error http test for channels_create
    expect error raised
    '''

    # clear existing data
    res = requests.delete(f'{url}/clear')

    # request list function with invalid token
    res = requests.post(f'{url}/channels/create', json={
        'token': -1,
        'name': 'Invalid Token Chl',
        'is_public': True
    })

    # assert error code 400 is raised
    assert res.status_code == 400
    res = res.json()
    res = res['message']

    # assert error message is per expected
    expected_message = 'Invalid token'
    assert striphtml(res) == expected_message

def test_http_channels_create_long_name(url):
    '''
    long name http test for channels_create
    expect error raised
    '''

    # clear existing data
    res = requests.delete(f'{url}/clear')

    # register a user for validated token
    res = requests.post(f'{url}/auth/register', json={
        'email': 'channelcreation@test.com',
        'password': 'T3stingP4ssw0rd',
        'name_first': 'Channel Creation',
        'name_last': 'Tester'
    })

    user_detail = res.json()

    # request create function with channel name exceeding 20 characters
    res = requests.post(f'{url}/channels/create', json={
        'token': user_detail['token'],
        "name": 'This is a Very Long Channel Name',
        "is_public": True
    })

    # assert error code 400 is raised
    assert res.status_code == 400
    res = res.json()
    res = res['message']

    # assert error message is per expected
    expected_message = 'Channel name cannot exceed 20 characters'
    assert striphtml(res) == expected_message

# the following function is obtained from stackoverflow to remove html tags from a given string
# https://stackoverflow.com/questions/3398852/using-python-remove-html-tags-formatting-from-a-string/3398951

def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    out = re.compile(r'<.*?>')
    return out.sub('', data)
