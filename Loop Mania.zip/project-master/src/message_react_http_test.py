import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from other import clear
from auth import auth_register
from channels import channels_create
from error import InputError
from datetime import datetime as date, timedelta, timezone
# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")
#url = 'http://127.0.01:1531'

def test_message_react(url):
    # #create two user
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()

    r = requests.post(f"{url}/auth/register", json={"email":'666588@gamil.com', "password":'123456',
        "name_first":"Zoe", "name_last":"Ma"})
    user_2 = r.json()

    # #create a channel
    r = requests.post(f"{url}/channels/create", json={"token":user_1['token'], "name":'channel_1',
        "is_public":"true"})
    temp = r.json()
    channelId_1 = temp['channel_id']

    #send message
    r = requests.post(f"{url}/message/send", json={"token":user_1['token'], "channel_id":channelId_1,
        "message":"hello world!"})
    temp = r.json()
    message_id = temp['message_id']
    assert (message_id == 1)

    #message react
    r = requests.post(f"{url}/message/react", json={"token":user_1['token'], "message_id":channelId_1,
        "react_id":1})
    result = r.json()
    assert(result == {})

    #test error 1
    r = requests.post(f"{url}/message/react", json={"token":user_2['token'], "message_id":channelId_1,
        "react_id":1})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "message_id is not a valid message within a channel that the authorised user has joined"
    assert(striphtml(r) == error_message1)

    #test error 2
    r = requests.post(f"{url}/message/react", json={"token":user_1['token'], "message_id":channelId_1,
        "react_id":3})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "react_id is not a valid React ID. The only valid react ID the frontend has is 1"
    assert(striphtml(r) == error_message1)

    #test error 3
    r = requests.post(f"{url}/message/react", json={"token":user_1['token'], "message_id":channelId_1,
        "react_id":1})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "Message with ID message_id already contains an active React with ID react_id from the authorised user"
    assert(striphtml(r) == error_message1)

def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    p = re.compile(r'<.*?>')
    return p.sub('', data)    

#test_message_react(url)