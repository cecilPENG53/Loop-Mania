from data import *
from channel import channel_invite, channel_details, channel_messages
from error import InputError, AccessError
import pytest
from channels import channels_create
from channel import channel_join
from auth import auth_register
from other import clear
from datetime import datetime as date
from helper_function import add_message, find_message
from message import message_send, message_pin, message_unpin

def test_message_unpin_1():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    #user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
    #send message from channel_1
    message_id = message_send(user_1['token'], 1, "I love python")
    message_pin(user_1['token'], 1)
    message_unpin(user_1['token'], 1)
    
    #test 1
    message_list = find_message(message_id)
    assert message_list == {}

def test_message_unpin_2():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    #user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
    #send message from channel_1
    message_send(user_1['token'], 1, "I love python")
    message_pin(user_1['token'], 1)
    #send message from channel_1
    #message_id = message_send(user_1['token'], 1, "I love python")
    
    #test 2 message_id is not a valid message
    with pytest.raises(InputError):
        message_unpin(user_1['token'], 2)

def test_message_unpin_3():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    #user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
    #send message from channel_1
    #message_id = message_send(user_1['token'], 1, "I love python")

    #test 3 Message with ID message_id already unpinned
    with pytest.raises(InputError):
        message_unpin(user_1['token'], 1)

def test_message_unpin_4():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
    #send message from channel_1
    message_send(user_1['token'], 1, "I love python")
    message_pin(user_1['token'], 1)
    channel_join(user_2['token'], 1)
    #test 4 The user is not an admin
    with pytest.raises(AccessError):
        message_unpin(user_2['token'], 1)
        
def test_message_unpin_5():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_2['token'], 'channel_1', 'true')
    #send message from channel_1
    message_send(user_2['token'], 1, "I love python")
    message_pin(user_2['token'], 1)
    #test 5 The authorised user is not a member of the channel that the message is within
    with pytest.raises(AccessError):
        message_unpin(user_1['token'], 1)

