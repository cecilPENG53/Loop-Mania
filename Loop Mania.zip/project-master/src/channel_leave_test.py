from data import *
from channel import channel_leave, channel_invite, channel_details
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
from datetime import datetime as date

# InputError when any of:Channel ID is not a valid channel
# AccessError when Authorised user is not a member of channel with channel_id

# get user from token, is channel valid, is a member of , delete the user from current channel("all users'), is a owner of : yes->delete from the owner list (remove_owner)

# channel_leave(token, channel_id)
def test_channel_leave():
 # reset dsta
    clear()
    
    # bulid two user
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')
    
    # create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
    channel_invite(user_1['token'], 1, user_2['u_id'])
    
    
    #channel_leave(user_2['token'], 1)
    

    # # test failure situation of initial
    # # Channel ID is not a valid channel
    with pytest.raises(InputError):
        channel_leave(user_1['token'], 2)
    
    with pytest.raises(InputError):
        channel_leave(user_2['token'], 2)
    
    # # when Authorised user is not a member of channel
    user_3 = auth_register('999999@gamil.com', '123456', 'Yun', 'MA')
    with pytest.raises(AccessError):
        channel_leave(user_3['token'], 1)
    
    # # test leave 
    channel_leave(user_2['token'], 1)
    with pytest.raises(AccessError):
        channel_details(user_2['token'], 1)


    # # test successful situation of initial
    assert channel_leave(user_1['token'], 1) == {}
    clear()


