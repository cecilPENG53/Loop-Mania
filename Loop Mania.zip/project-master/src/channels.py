'''
Channels module that contain functions to list channels, and create channels
'''

import data
from error import InputError, AccessError
from helper_function import getUserId
def channels_list(token):
    '''
    given token perform checks on token validity then returns the channels
    that the user (associated with the token) is in
    '''

    # token check
    invalid_token = True

    if token in data.valid_token:
            invalid_token = False

    # invalid token raises an error
    if invalid_token is True:
        raise AccessError(description='Invalid token')

    result = {
        'channels': []
    }

    # find channels that user is in, append them to a list
    for user in data.user_data:
        if user['token'] == token:
            for channel in user['channels']:
                result['channels'].append(channel)

    return result

def channels_listall(token):
    '''
    given token
    perform checks on token validity
    then returns all of the channels that have been created
    '''

    # token check
    invalid_token = True

    if token in data.valid_token:
            invalid_token = False

    # invalid token raises an error
    if invalid_token is True:
        raise AccessError(description='Invalid token')

    # loops through data of all channels created
    # append channel ids and names to list
    result = {
        'channels': []
    }

    for channel in data.channel_data:
        result['channels'].append(
            {
                'channel_id': channel['channel_id'],
                'name': channel['name'],
            },
        )

    return result

def channels_create(token, name, is_public):
    '''
    given token, channel's name and privacy setting,
    validates token and length of channel's name
    returns channel id on successful creation
    '''

    # token check
    invalid_token = True

    for tokens in data.valid_token:
        if tokens is token:
            invalid_token = False

    # raise error if token is invalid
    if invalid_token is True:
        raise AccessError(description='Invalid token')

    # raise error if channel's name is more than 20 characters long
    if len(name) > 20:
        raise InputError(description='Channel name cannot exceed 20 characters')

    # calculate and assign channel_id
    new_channel_id = 1 + len(data.channel_data)

    # use token provide to retrieve user's id and name from user_data
    # store new channel's id and name in user_data
    owner_id = -1
    owner_name_first = ''
    owner_name_last = ''

    # loop to find user with the same token
    for user in data.user_data:
        if user['token'] == token:
            owner_id = user['u_id']
            owner_name_first = user['name_first']
            owner_name_last = user['name_last']
            user['channels'].append(
                {
                    'channel_id': new_channel_id,
                    'name': name,
                }
            )

    if is_public == 'true' or is_public == True:
        is_public = True
    else:
        is_public = False

    # adds relevant data to channel data
    data.channel_data.append(
        {
            'channel_id': new_channel_id,
            'name': name,
            'is_public': is_public,
            'owners': [
                {
                    'u_id' : owner_id,
                    'name_first': owner_name_first,
                    'name_last': owner_name_last,
                }
            ],
            'users': [
                {
                    'u_id' : owner_id,
                    'name_first': owner_name_first,
                    'name_last': owner_name_last,
                }
            ],
            'messages': [],
            'standup_time_finish': None,
            'standup_messages': None,
            'standup_starter': None
        }
    )

    return {'channel_id': new_channel_id}
