from data import * 
from channel import channel_invite, channel_details, channel_messages
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
from datetime import datetime as date
from helper_function import add_message, find_message
from message import message_send, message_react, message_unreact

def test_message_unreact():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')

    #send message from channel_1

    message_id = message_send(user_1['token'], 1, "I love python")

    message_react(user_1['token'], 1, 1)
    #test 1
    message_list = find_message(message_id['message_id'])
    react_list = message_list['reacts']
    uid_list = react_list[0]['u_ids']
    assert uid_list == [0]
    message_unreact(user_1['token'], 1, 1)
    assert uid_list == []

    #test 2 message_id is not a valid message within a channel that the authorised user has joined
    with pytest.raises(InputError):
        message_unreact(user_2['token'], message_id['message_id'], 1)

    #test 3 react_id is not a valid React ID. The only valid react ID the frontend has is 1
    with pytest.raises(InputError):
        message_unreact(user_1['token'], 1, 0)

    #test 4 Message with ID message_id does not contain an active React with ID react_id
    with pytest.raises(InputError):
        message_unreact(user_1['token'], 1, 1)
