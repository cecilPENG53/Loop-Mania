'''
this file is used to store data inputs from obtained from other files
this file can be imported to access stored data

user_data is used to store data inputs of all users
data is stored in the form of a list of dictionaries, where the 
dictionaries store the following keys and value:
'''

#       'u_id'          : integer value of an assigned user id
#       'email'         : user's registered email
#       'password'      : user's password
#       'name_first'    : user's first name
#       'name_last'     : user's last name
#       'channels'      : list of dictionary containing channel_id
#                         and name that the user is in
#       'token'         : stores a user's current token
#                         key's value is empty if user is offline
user_data = [
    {
        'u_id': 3,
        'email': 'sampledata@abc.com',
        'password': 'aD3centPassw0rd',
        'name_first': 'Jane',
        'name_last': 'Doe',
        'handle_str': 'janedoe',
        'channels': [
            {
                'channel_id': 1,
                'name': 'Sample Channel',
            }
        ],
        'permission_id': 1,
        'token': 'sampledata@abc.com',
        'profile_img_url': 'http://localhost:5001/imgurl/adfnajnerkn23k4234.jpg',
        'reset_code': None,
    }
]

'''
channel_data is used to store data inputs of all channels.
data is stored similar to user_data where the dictionaries 
store the following keys and value:
'''

#       'channel_id'    : integer value of an assigned channel id
#       'channel_name'  : user's first name
#       'is_public'     : string that contains 'true' or 'false'
#       'owners'        : list of dictionaries of users who are owner(s)
#                         stores user's id and name in dictionary
#       'users'         : list of user ids that are regular users
#                         stores user's id and name in dictionary
#       'messages'      : list of messages in channel
channel_data = [
    {
        'channel_id': 1,
        'name': 'Sample Channel',
        'is_public': 'true',
        'owners': [{
            'u_id' : 3,
            'name_first': 'Jane',
            'name_last': 'Doe',
            'profile_img_url': 'http://localhost:5001/imgurl/adfnajnerkn23k4234.jpg'
        }
        , ],
        'users': [{
            'u_id' : 3,
            'name_first': 'Jane',
            'name_last': 'Doe',
            'profile_img_url': 'http://localhost:5001/imgurl/adfnajnerkn23k4234.jpg'
        }],
        'messages': [
            {

            },
        ],
        'standup_time_finish': None, # if no active standup, UTC time in seconds if active standup
        'standup_messages': None,
        'standup_starter': None
    },
]

'''
valid_tokens stores a list of emails of users who are logged in

    for example, assuming that u_id: 1 is logged in
    print(valid_token) will produce output
    ['sampledata@abc.com']
'''
valid_token = []
