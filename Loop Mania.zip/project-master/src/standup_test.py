''' test file for standup.py '''

from standup import standup_start, standup_active, standup_send
from data import user_data, channel_data, valid_token
from auth import auth_register
from channels import channels_create
from other import clear
from time import sleep
import pytest
from error import InputError, AccessError
from datetime import datetime, timezone
from random import choice
import string

def get_timestamp():
    dt = datetime.utcnow()
    dt = int(dt.replace(tzinfo=timezone.utc).timestamp())
    return dt

def test_standup_start():
    ''' test basic functionality of startup_start '''
    
    # clear existing data
    clear()

    # register a user for valid token
    created_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')

    # create a channel using valid token
    created_channel = channels_create(created_user['token'],'standup test', True)

    # obtain created user's handle
    for user in user_data:
        if user['token'] == created_user['token']:
            standup_starter = user['handle_str']

    # check channel data doesn't have stored time_finish
    for channel in channel_data:
        if channel['channel_id'] == created_channel['channel_id']:
            assert channel['standup_time_finish'] is None

    # start standup
    time_finish = standup_start(created_user['token'], created_channel['channel_id'], 1)

    # check channel data have similar time_finish stored
    for channel in channel_data:
        if channel['channel_id'] == created_channel['channel_id']:
            assert channel['standup_time_finish'] == time_finish['time_finish']
            assert channel['standup_starter'] == standup_starter

    # get current timestamp and using standup_active to check if standup is currently active
    dt = get_timestamp()
    
    # if timestamp obtained is less than time_finish,
        # check that standup_active result agrees that there is an active standup
        # and wait for timestamp difference
    if dt < time_finish['time_finish']:
        standup_stat = standup_active(created_user['token'], created_channel['channel_id'])
        assert standup_stat['is_active'] is True
        sleep(time_finish['time_finish']-dt)
    
    # check that standup is not active/no longer active
    standup_stat = standup_active(created_user['token'], created_channel['channel_id'])
    assert standup_stat['is_active'] is False

    # check channel data no longer have stored time_finish
    for channel in channel_data:
        if channel['channel_id'] == created_channel['channel_id']:
            assert channel['standup_time_finish'] is None

def test_standup_start_invalid_token():
    ''' test if standup_start raises error an invalid token '''
    
    # clear existing data
    clear()

    # declare parameters for testing
    invalid_token = "invalid_token~"
    channel_id = 1
    length = 15

    # check that AccessError is raised
    with pytest.raises(AccessError):
        assert standup_start(invalid_token, channel_id, length)

def test_standup_start_invalid_channel_id():
    ''' test if standup_start raises error an invalid channel_id '''
    
    # clear existing data
    clear()

    # register a user for valid token
    created_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')

    # declare other parameters for testing
    channel_id = 5000
    length = 15

    # check that InputError is raised
    with pytest.raises(InputError):
        assert standup_start(created_user['token'], channel_id, length)

def test_standup_start_ongoing_standup():
    ''' test if standup_start checks if there's an ongoing standup '''
    
    # clear existing data
    clear()

    # register a user for valid token
    created_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')

    # create a channel using valid token
    created_channel = channels_create(created_user['token'],'standup test', True)

    # declare other parameters
    length = 15

    # start first standup
    standup_start(created_user['token'], created_channel['channel_id'], length)

    # check that InputError is raised when an attempt to start a standup is made again
    with pytest.raises(InputError):
        assert standup_start(created_user['token'], created_channel['channel_id'], length)

def test_standup_active():
    ''' test basic functionality of standup_active '''
    
    # clear existing data
    clear()

    # register a user for valid token
    created_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')

    # create a channel using valid token
    created_channel = channels_create(created_user['token'],'standup test', True)

    # check no active stand up when none is started
    standup_stat = standup_active(created_user['token'], created_channel['channel_id'])
    assert standup_stat['is_active'] is False
    assert standup_stat['time_finish'] is None

    # declare other parameters
    length = 1

    # start first standup
    time_finish = standup_start(created_user['token'], created_channel['channel_id'], length)

    # check function reflects standup data when there is an active standup
    if get_timestamp() < time_finish['time_finish']:
        standup_stat = standup_active(created_user['token'], created_channel['channel_id'])
        assert standup_stat['is_active'] is True
        assert standup_stat['time_finish'] == time_finish['time_finish']

        # sleep for standup to be over
        sleep(time_finish['time_finish']-get_timestamp())
    else:
        for channel in channel_data:
            if channel['channel_id'] == created_channel['channel_id']:
                assert channel['standup_messages'] is None
                assert channel['standup_starter'] is None
    
    # check that function reflect correct standup data after standup is over
    standup_stat = standup_active(created_user['token'], created_channel['channel_id'])
    assert standup_stat['is_active'] is False
    assert standup_stat['time_finish'] is None

def test_standup_active_invalid_token():
    ''' test if standup_active raises error an invalid token '''
    
    # clear existing data
    clear()

    # declare parameters for testing
    invalid_token = "invalid_token~"
    channel_id = 1

    # check that AccessError is raised
    with pytest.raises(AccessError):
        assert standup_active(invalid_token, channel_id)

def test_standup_active_invalid_channel_id():
    ''' test if standup_active raises error an invalid channel_id '''
    
    # clear existing data
    clear()

    # register a user for valid token
    created_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')

    # declare other parameters for testing
    channel_id = 5000

    # check that InputError is raised
    with pytest.raises(InputError):
        assert standup_active(created_user['token'], channel_id)

def test_standup_send():
    ''' test basic functionality of standup_send '''
    
    # clear existing data
    clear()

    # valid token
    valid_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')
    token = valid_user['token']

    # valid channel id
    valid_channel = channels_create(token,'standup test', True)
    channel_id = valid_channel['channel_id']

    # valid message
    message = 'I am valid!'

    # valid standup
    standup_start(token, channel_id, 10)

    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            assert channel['standup_messages'] is None

    assert standup_send(token, channel_id, message) == {}

    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            assert channel['standup_messages'] is not None

def test_standup_send_invalid_token():
    ''' test if standup_send raises error an invalid token '''
    
    # clear existing data
    clear()

    # invalid token
    valid_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')
    token = -100

    # valid channel id
    valid_channel = channels_create(valid_user['token'],'standup test', True)
    channel_id = valid_channel['channel_id']

    # valid message
    message = 'I am valid!'

    with pytest.raises(InputError):
        assert standup_send(token, channel_id, message)

    clear()

def test_standup_send_invalid_channel_id():
    ''' test if standup_send raises error an invalid channel_id '''
    
    # clear existing data
    clear()

    # valid token
    valid_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')
    token = valid_user['token']

    # invalid channel id
    channel_id = -100

    # valid message
    message = 'I am valid!'

    with pytest.raises(InputError):
        assert standup_send(token, channel_id, message)

    clear()

def test_standup_send_long_message():
    ''' test if standup_send raises error for messages longer than 1000 characters '''
    
    # clear existing data
    clear()

    # valid token
    valid_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')
    token = valid_user['token']

    # valid channel id
    valid_channel = channels_create(valid_user['token'],'standup test', True)
    channel_id = valid_channel['channel_id']

    # invalid message
    message = long_message()

    with pytest.raises(InputError):
        assert standup_send(token, channel_id, message)

    clear()

def test_standup_send_inactive_standup():
    ''' test if standup_send raises error when there is no ongoing standup '''
    
    # clear existing data
    clear()

    # valid token
    valid_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')
    token = valid_user['token']

    # valid channel id
    valid_channel = channels_create(valid_user['token'],'standup test', True)
    channel_id = valid_channel['channel_id']

    # valid message
    message = 'I am valid!'

    # whereas not valid standup start/active

    with pytest.raises(InputError):
        assert standup_send(token, channel_id, message)

    clear()


def test_standup_send_unauthorised_member():
    ''' test if standup_send raises error when user of token is not a member of the channel '''
    
    # clear existing data
    clear()

    # invalid token
    valid_user = auth_register('standup@tester.com','T3sterP@ssw0rd','standup','tester')
    token = valid_user['token']

    auth_user = auth_register('standup@testerrr.com','T3sterP@ssw0rddd','standuppp','testerrr')

    # valid channel id
    valid_channel = channels_create(auth_user['token'],'standup test', True)
    channel_id = valid_channel['channel_id']

    # valid message
    message = 'I am valid!'

    with pytest.raises(AccessError):
        assert standup_send(token, channel_id, message)

    clear()


def long_message():
    '''
    take a random message (up to 1001 chars) for test
    '''
    return ''.join([choice(string.ascii_letters) for i in range(1001)])