from data import * 
from channel import channel_invite, channel_details, channel_messages
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
from datetime import datetime as date
from helper_function import add_message
from message import message_send, message_remove

def test_message_remove():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create two channel
    channels_create(user_1['token'], 'channel_1', 'true')
    channels_create(user_2['token'], 'channel_2', 'true')

    message_send(user_1['token'], 1, "I love python")
    message_send(user_2['token'], 2, "I love python tooooo!")


    # # #InputError when any of:Message (based on ID) no longer exists
    with pytest.raises(InputError):
        message_remove(user_2['token'], 3)
    
    # # #The authorised user is not an owner of this channel or the flockr
    with pytest.raises(AccessError):
        message_remove(user_2['token'], 1)

    # #create user_3
    user_3 = auth_register('10086@gamil.com', '123456', 'Jack', 'MA')
    channel_invite(user_1['token'], 1, user_3['u_id'])

 

    # #Message with message_id was sent by the authorised user making this request
    with pytest.raises(AccessError):
        message_remove(user_3['token'], 1)

    #test the message_id is unique
    message_remove(user_1['token'], 1)
    result = message_send(user_2['token'], 2, "the message_id is 3")
    assert (result['message_id'] == 3)

