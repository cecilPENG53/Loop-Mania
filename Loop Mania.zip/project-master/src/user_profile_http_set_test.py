import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from auth import auth_register
from data import user_data
from error import InputError
from other import clear
from random import choice
import string

# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

def test_profile_email_valid(url):
    clear()
    r = requests.post(f"{url}/auth/register", json={"email":'ankitrai326@gmail.com', "password":'123456',"name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()
    
    r = requests.put(f"{url}/user/profile/setemail", json={"token":user_1['token'], "email":'my.ownsite@ourearth.org'})
    result = r.json()
    assert (result == {})
    
    # clear existing data
    r = requests.delete(f'{url}/clear')

    r = requests.post(f"{url}/auth/register", json={"email":'my.ownsite@ourearth.org', "password":'7654321',"name_first":"Ma", "name_last":"Zoe"})
    user_2 = r.json()
    
    r = requests.put(f"{url}/user/profile/setemail", json={"token":user_2['token'], "email":'ankitrai326@gmail.com'})
    result = r.json()
    assert (result == {})

def test_profile_setemail_invalid_emailFormat(url):
    clear()
    r = requests.post(f"{url}/auth/register", json={"email":'ankitrai326@gmail.com', "password":'123456',"name_first":"Li", "name_last":"Ming"})
    user = r.json()
    
    r = requests.put(f"{url}/user/profile/setemail", json={"token":user['token'], "email":'ankitrai326.com'})
    r = r.json()
    r = r['message']
    error_message1 = 'Email entered is not a valid email'
    assert(striphtml(r) == error_message1)
    
    r = requests.put(f"{url}/user/profile/setemail", json={"token":user['token'], "email":'123'})
    r = r.json()
    r = r['message']
    error_message2 = 'Email entered is not a valid email'
    assert(striphtml(r) == error_message2)
    
    r = requests.put(f"{url}/user/profile/setemail", json={"token":user['token'], "email":'1531@'})
    r = r.json()
    r = r['message']
    error_message3 = 'Email entered is not a valid email'
    assert(striphtml(r) == error_message3)
    
def test_profile_setemail_invalid_duplicate(url):
    clear()
    r = requests.post(f"{url}/auth/register", json={"email":'ankitrai326@gmail.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user = r.json()
    
    r = requests.put(f"{url}/user/profile/setemail", json={"token":user['token'], "email":'ankitrai326@gmail.com'})
    r = r.json()
    r = r['message']
    error_message = 'Email address is already being used by another user'
    assert(striphtml(r) == error_message)

def test_profile_sethandle_valid(url):
    clear()
    r = requests.post(f"{url}/auth/register", json={"email":'ankitrai326@gmail.com', "password":'123456',"name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()
    
    r = requests.put(f"{url}/user/profile/sethandle", json={"token":user_1['token'], "handle_str":'mingli'})
    result = r.json()
    assert (result == {})
    
def test_profile_sethandle_invalid_length(url):
    clear()
    r = requests.post(f"{url}/auth/register", json={"email":'ankitrai326@gmail.com', "password":'123456',"name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()
    
    r = requests.put(f"{url}/user/profile/sethandle", json={"token":user_1['token'], "handle_str":'lm'})
    r = r.json()
    r = r['message']
    error_message1 = 'handle_str must be between 3 and 20 characters'
    assert(striphtml(r) == error_message1)
    
    r = requests.post(f"{url}/auth/register", json={"email":'my.ownsite@ourearth.org', "password":'7654321',"name_first":"Ma", "name_last":"Zoe"})
    user_2 = r.json()
    
    r = requests.put(f"{url}/user/profile/sethandle", json={"token":user_2['token'],"handle_str":'mamamamamamazoezoezoezoezoe'})
    r = r.json()
    r = r['message']
    error_message2 = 'handle_str must be between 3 and 20 characters'
    assert(striphtml(r) == error_message2)
    
def test_profile_sethandle_invalid_duplicate(url):
    clear()
    r = requests.post(f"{url}/auth/register", json={"email":'ankitrai326@gmail.com', "password":'123456',"name_first":"Li", "name_last":"Ming"})
    user = r.json()
    
    r = requests.put(f"{url}/user/profile/sethandle", json={"token":user['token'], "handle_str":'liming'})
    r = r.json()
    r = r['message']
    error_message = 'Handle is already used by another user'
    assert(striphtml(r) == error_message)
    
def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    p = re.compile(r'<.*?>')
    return p.sub('', data)
