"""
the interface of channel
"""
from data import user_data, channel_data, valid_token
from error import InputError, AccessError
from helper_function import is_InChannel, find_channel

def channel_invite(token, channel_id, u_id):
    '''
    Invites a user (with user id u_id) to join a channel with ID channel_id.
    Once invited the user is added to the channel immediately
    '''
    #first find the channel exsit
        #not any channel
    i = 0
    for channel in channel_data:
        if channel['channel_id'] is not None:
            i += 1
    if i == 0:
        raise InputError("channel_id does not refer to a valid")
        #not channel of inputing
    is_channel_exsit = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            is_channel_exsit = True
    if is_channel_exsit is False:
        raise InputError("channel_id does not refer to a valid")

    #u_id does not refer to a valid user
    id_exsit = False
    for id_number in user_data:
        if id_number['u_id'] == u_id:
            id_exsit = True
    if id_exsit is False:
        raise InputError("u_id does not refer to a valid user")

    #Interation 2 sepcial condition: the user who invited has been in channel
    curr_channel = find_channel(channel_id)
    result = is_InChannel(curr_channel, u_id)
    if result is True:
        raise InputError("the user has been in this channel")
    

    #whenthe authorised user is not already a member of the channel
        #first from token get the user
    author_user = 0
    for id_number in user_data:
        if id_number['token'] == token:
            author_user = id_number['u_id']
            break
        #check user is channel author
    is_author = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            for id_number in channel['owners']:
                if id_number['u_id'] == author_user:
                    is_author = True
                    break
    if is_author is False:
        raise AccessError("authorised user is not already a member of the channel")

    #achive: not occur error, add user in channel
        #find user detail who invited
    img = False
    for user in user_data:
        if user['u_id'] == u_id:
            name_first = user['name_first']
            name_last = user['name_last']
            if 'profile_img_url' in user:
                img = True
                profile_img_url = user['profile_img_url']

    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            if img is True:
                channel['users'].append({
                    'u_id' : u_id,
                    'name_first': name_first,
                    'name_last': name_last,
                    'profile_img_url': profile_img_url
                })
            else:
                channel['users'].append({
                    'u_id' : u_id,
                    'name_first': name_first,
                    'name_last': name_last
                })
    return {
    }


def channel_details(token, channel_id):
    '''
    Given a Channel with ID channel_id that the authorised user is part of,
    provide basic details about the channel
    '''
    #######Requirement
    #Given a Channel with ID channel_id that the authorised user is part of,
    # provide basic details about the channel

    #InputError when any of:Channel ID is not a valid channel
    is_channel_exsit = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            is_channel_exsit = True

    if is_channel_exsit is False:
        raise InputError("Channel ID is not a valid channel")

    #AccessError whenAuthorised user is not a member of channel with channel_id
    author_user = -1
    for id_number in user_data:
        if id_number['token'] == token:
            author_user = id_number['u_id']
            break
        #check user is channel author

    is_author = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            for id_number in channel['users']:
                if id_number['u_id'] == author_user:
                    is_author = True
                    break

    if is_author is False:
        raise AccessError("authorised user is not already a member of the channel")

    #achiving
        #find the channel
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            name = channel['name']
            owners = channel['owners']
            users = channel['users']

    return {
        'name' : name,
        'owner_members' : owners,
        'all_members' : users
    }

def channel_messages(token, channel_id, start):
    '''
    Given a Channel with ID channel_id that the authorised user is part of,
    return up to 50 messages between index "start" and "start + 50".
    Message with index 0 is the most recent message in the channel.
    This function returns a new index "end" which is the value of "start + 50", or,
    if this function has returned the least recent messages in the channel,
    returns -1 in "end" to indicate there are no more messages to load after this return.
    '''
    #from token get the u_id
    author_user = -1
    for id_user in user_data:
        if id_user['token'] == token:
            author_user = id_user['u_id']
            break
    #InputError when any of:Channel ID is not a valid channel
    is_channel_exsit = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            is_channel_exsit = True

    if is_channel_exsit is False:
        raise InputError("Channel ID is not a valid channel")

    #AccessError whenAuthorised user is not a member of channel with channel_id
    is_author = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            for id_user in channel['users']:
                if id_user['u_id'] == author_user:
                    is_author = True
                    break

    if is_author is False:
        raise AccessError("authorised user is not already a member of the channel")

    #get the message
    mesg = []

    #get the channel
    curr_channel = {}
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            curr_channel = channel

    #InputError:start is greater than the total number of messages in the channel
    if start > len(curr_channel['messages']):
        raise InputError("start is greater than the total number of messages in the channel")

    if len(curr_channel['messages']) > start + 50:
        mesg = curr_channel['messages'][start : start + 51]
    else:
        mesg = curr_channel['messages'][start:]
    #ensure the end value
    end = start + 50
    if end > len(curr_channel['messages']):
        end = -1

    return {
        'messages' : mesg,
        'start' : start,
        'end' : end
    }
    # return {
    #     'messages': [
    #         {
    #             'message_id': 1,
    #             'u_id': 1,
    #             'message': 'Hello world',
    #             'time_created': 1582426789,
    #         }
    #     ],
    #     'start': 0,
    #     'end': 50,
    # }

# get user from token,
# is channel valid,
# is a member of ,
# delete the user from current channel("all users'),
# is a owner of: yes->delete from the owner list (remove_owner)
def channel_leave(token, channel_id):
    """
    Given a channel ID, the user removed as a member of this channel
    """
    # get user from token
    author_user = -1
    for id_user in user_data:
        if id_user['token'] == token:
            author_user = id_user['u_id']
            break
    # InputError when any of: Channel ID is not a valid channel
    is_channel_exsit = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            is_channel_exsit = True

    if is_channel_exsit is False:
        raise InputError("Channel ID is not a valid channel")

    #AccessError: when Authorised user is not a member of channel with channel_id
    is_author = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            for id_user in channel['users']:
                if id_user['u_id'] == author_user:
                    is_author = True
                    break

    if is_author is False:
        raise AccessError(" authorised user is not already a member of the channel")

    # for channel in channel_data:
    #     if channel['is_public'] is False:
    #         raise AccessError(" private channel can only be joined by invitation")

    #first find the channel, get the list of user and owners
    channel_users = []

    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            channel_users = channel['users']
    #find the user in users of channel_data
    user_delete = {}
    for user in channel_users:
        if user['u_id'] == author_user:
            user_delete = user
            break

    #delete user
    channel_users.remove(user_delete)
    return {
    }

# get user from token,
# is channel valid,
# is the channel private (is the user admin)
# if sucess append the user to all_users
def channel_join(token, channel_id):
    """
    Given a channel_id of a channel
    that the authorised user can join, adds them to that channel
    """
    # # get user from token
    # author_user = 0
    # for id_user in user_data:
    #     if id_user['token'] == token:
    #         author_user = id_user['u_id']
    #         break

    # InputError when any of: Channel ID is not a valid channel
    is_channel_exsit = False
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            is_channel_exsit = True

    if is_channel_exsit is False:
        raise InputError("Channel ID is not a valid channel")

    # AccessError: Channel is not private
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            if channel['is_public'] == False:
                raise AccessError(" private channel can only be joined by invitation")

    # get users infomation
    img = False
    for users in user_data:
        if users['token'] == token:
            u_id = users['u_id']
            name_first = users['name_first']
            name_last = users['name_last']
            if 'profile_img_url' in users:
                img = True
                profile_img_url = users['profile_img_url']
            break
    # join users
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            if img is True:
                channel['users'].append(
                    {
                        'u_id' : u_id,
                        'name_first': name_first,
                        'name_last': name_last,
                        'profile_img_url': profile_img_url
                    }
                )
            else:
                channel['users'].append(
                    {
                        'u_id' : u_id,
                        'name_first': name_first,
                        'name_last': name_last
                    }
                )
    return {
    }


def channel_addowner(token, channel_id, u_id):
    """
    Make user with user id u_id an owner of this channel
    """

    #1, test token valid (if a valid login flockr user)
    ture_valid_token = 0

    for v_token in valid_token:
        if token == v_token:        #valid login flockr user
            ture_valid_token += 1

    if ture_valid_token != 1:
        raise AccessError("You are not a user of flockr")

    #2, test channel_id existence
    valid_channel = False

    for channels in channel_data:
        if channel_id == channels['channel_id']:    #valid channel_id
            valid_channel = True

    if valid_channel is not True:
        raise InputError("This channel is not exist")

    #3, test token again (if a valid owner of this channel)
    for users in user_data:
        if token == users['token']:
            authorised_id = users['u_id']

    for channels in channel_data:
        if channel_id == channels['channel_id']:    #target channel_id
            for owners in channels['owners']:
                if authorised_id == owners['u_id']:
                    ture_valid_token += 1           #valid owner of channel

    if ture_valid_token != 2:
        raise AccessError("You are not an owner of this channel")

    #4, test u_id valid
    valid_uid = False

    for users in user_data:
        if u_id == users['u_id']:
            valid_uid = True

    if valid_uid is not True:
        raise AccessError("This id is not a user of flockr")

    for channels in channel_data:
        if channel_id == channels['channel_id']:    #target channel_id
            for owners in channels['owners']:
                if u_id == owners['u_id']:
                    raise InputError("This user is already an owner of the channel")
                #else: valid u_id

    #5, add member and owner
    img = False
    for users in user_data:
        if u_id == users['u_id']:
            name_first = users['name_first']        #take first name
            name_last = users['name_last']          #take last name
            if 'profile_img_url' in users:          #take img url if exists
                img = True
                profile_img_url = users['profile_img_url']

    #check if a member of channel
    is_member = False

    for channels in channel_data:
        if channel_id == channels['channel_id']:
            for users in channels['users']:
                if u_id == users['u_id']:
                    is_member = True

    for channels in channel_data:
        if channel_id == channels['channel_id']:
            if is_member is not True:
                if img is True:
                    channels['users'].append({          #add the user to members
                        'u_id' : u_id,
                        'name_first': name_first,
                        'name_last': name_last,
                        'profile_img_url' : profile_img_url
                    })
                else:
                    channels['users'].append({          #add the user to members
                        'u_id' : u_id,
                        'name_first': name_first,
                        'name_last': name_last
                    })
            if img is True:
                channels['owners'].append({             #add the user to owners
                    'u_id' : u_id,
                    'name_first': name_first,
                    'name_last': name_last,
                    'profile_img_url' : profile_img_url
                })
            else:
                channels['owners'].append({             #add the user to owners
                        'u_id' : u_id,
                        'name_first': name_first,
                        'name_last': name_last
                })

    return {}


def channel_removeowner(token, channel_id, u_id):
    """
    Remove user with user id u_id an owner of this channel
    """

    #1, test token valid
    ture_valid_token = 0

    for v_token in valid_token:
        if token == v_token:        #valid login flockr user
            ture_valid_token += 1

    if ture_valid_token != 1:
        raise AccessError("You are not a user of flockr")

    #2, test channel_id existence
    valid_channel = False

    for channels in channel_data:
        if channel_id == channels['channel_id']:    #valid channel_id
            valid_channel = True

    if valid_channel is not True:
        raise InputError("This channel is not exist")

    #3, test token again
    for users in user_data:
        if token == users['token']:
            authorised_id = users['u_id']

    for channels in channel_data:
        if channel_id == channels['channel_id']:    #target channel_id
            for owners in channels['owners']:
                if authorised_id == owners['u_id']:
                    ture_valid_token += 1           #valid owner of channel

    if ture_valid_token != 2:
        raise AccessError("You are not an owner of this channel")

    #4, test u_id valid
    valid_uid = False

    for users in user_data:
        if u_id == users['u_id']:
            valid_uid = True

    if valid_uid is not True:
        raise AccessError("This id is not a user of flockr")

    valid_owner = False

    for channels in channel_data:
        if channel_id == channels['channel_id']:    #target channel_id
            for owners in channels['owners']:
                if u_id == owners['u_id']:
                    valid_owner = True

    if valid_owner is not True:
        raise InputError("This user is not an owner of the channel yet")

    #5, remove owner
    for users in user_data:
        if u_id == users['u_id']:
            name_first = users['name_first']        #take first name
            name_last = users['name_last']          #take last name

    for channels in channel_data:
        if channel_id == channels['channel_id']:
            for owners in channels['owners']:
                if u_id == owners['u_id']:
                    if 'profile_img_url' in owners:
                        profile_img_url = owners['profile_img_url']
                        channels['owners'].remove({     #remove the user from owners
                            'u_id' : u_id,
                            'name_first': name_first,
                            'name_last': name_last,
                            'profile_img_url': profile_img_url
                        })
                    else:
                        channels['owners'].remove({     #remove the user from owners
                            'u_id' : u_id,
                            'name_first': name_first,
                            'name_last': name_last
                        })

    return {}
