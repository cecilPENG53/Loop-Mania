'''
test file for functions in channels.py
'''

import pytest
import auth
import channels
from error import InputError, AccessError
from other import clear

def test_channels_list():
    '''
    since channels_list returns only channels that the user is in, we can create
    two channels using two different users, but not have each user join both channels

        the output from channels_list can be compared to an expected outcome defined in
        the test function
        assumes that auth_register and channel_create works
    '''

    # remove existing data user clear()
    clear()

    # establish data objects to use for test
    email_1 = 'channel1@test.com'
    email_2 = 'channel2@test.com'
    password = 'T3stingP4ssw0rd'
    name_first_1 = 'Channel One'
    name_first_2 = 'Channel Two'
    name_last = 'Tester'
    channel_name_1 = 'Channel 1'
    channel_name_2 = 'Channel 2'

    # use established data to register two users, data returned stored in result_1 and result_2
    # for user 1 and 2 respectively
    result_1 = auth.auth_register(email_1, password, name_first_1, name_last)
    result_2 = auth.auth_register(email_2, password, name_first_2, name_last)

    # use tokens returned from user creation to create two different channels
    channel_id_result = channels.channels_create(result_1['token'], channel_name_1, True)
    channels.channels_create(result_2['token'], channel_name_2, True)

    # establish expected outcome based on channel_id obtained and channel_name used
    expected_outcome = {
        'channels': [{
            'channel_id': channel_id_result['channel_id'],
            'name': channel_name_1,
        },]
    }

    # use channels_list and token output from previous creation to produce output
    actual_outcome = channels.channels_list(result_1['token'])

    # compare actual output from channels_list function to established expected outcome
    assert actual_outcome == expected_outcome

def test_channels_list_invalid_token():
    '''
    the following test, tests if an AccessError exception is raised when an
    invalid token is provided for channels_list
    '''

    # remove existing data user clear()
    clear()

    # establish an invalid token
    invalid_token = -1

    # attempt to use invalid token in channels_list function
        # expect function to raise an error
    with pytest.raises(AccessError):
        assert channels.channels_list(invalid_token)

def test_channels_listall():
    '''
    since channels_listall returns all channels regardless of privacy settings and whether
    the user is in the channel, we can create two channels using two different users,
    but not have each user join both channels. One of the channels will be set to public,
    while the other is private.
        the output from channels_listall should include both channels
        assumes that auth_register and channel_create works
    '''

    # remove existing data user clear()
    clear()

    # establish data objects to use for test
    email_1 = 'publicchannel@test.com'
    email_2 = 'privatechannel@test.com'
    password = 'T3stingP4ssw0rd'
    name_first_1 = 'Public'
    name_first_2 = 'Private'
    name_last = 'Tester'
    channel_name_1 = 'Public Channel'
    channel_name_2 = 'Private Channel'

    # use established data to register two users, data returned stored in result_1 and result_2
    # for user 1 and 2 respectively
    result_1 = auth.auth_register(email_1, password, name_first_1, name_last)
    result_2 = auth.auth_register(email_2, password, name_first_2, name_last)


    # use tokens returned from user creation to create two different channels
    first_id_result = channels.channels_create(result_1['token'], channel_name_1, True)
    second_id_result = channels.channels_create(result_2['token'], channel_name_2, False)

    # establish expected outcome based on channel_ids obtained and channel_names used
    expected_outcome = {
        'channels': [{
            'channel_id': first_id_result['channel_id'],
            'name': channel_name_1,
        }, {
            'channel_id': second_id_result['channel_id'],
            'name': channel_name_2
        },]
    }

    # use channels_listall and token output from previous creation to produce output
    actual_outcome = channels.channels_listall(result_1['token'])

    # compare actual output from channels_listall function to established expected outcome
    assert actual_outcome == expected_outcome

def test_channels_listall_invalid_token():
    '''
    the following test, tests if an AccessError exception is raised when an invalid token
    is provided for channels_listall
    '''

    #remove existing data user clear()
    clear()

    # establish an invalid token
    invalid_token = -1

    # attempt to use invalid token in channels_listall function
        # expect function to raise an AccessError
    with pytest.raises(AccessError):
        assert channels.channels_listall(invalid_token)

def test_channels_create():
    '''
    since channels_create returns the channel_id, we can check if the channel is created
    by using channels_listall to ensure that the output from channels_listall, contains
    the return from channels_create
        assumes that auth_register and channels_listall works
    '''

    # remove existing data user clear()
    clear()

    # establish data objects to use for test
    email = 'channelcreation@test.com'
    password = 'T3stingP4ssw0rd'
    name_first = 'Channel Creation'
    name_last = 'Tester'
    channel_name = 'Regular Channel'

    # use established data in auth_register function call and channels_create function call,
    # then store results in register_result and create_result respectively
        # channels_create will use token obtained from register_result
    register_result = auth.auth_register(email, password, name_first, name_last)
    create_result = channels.channels_create(register_result['token'], channel_name, True)

    # use function channels_listall to produce list of all channels created, regardless of
    # privacy settings and user existence in channel, the list of result is stored in
    # data object listall_result
        # channels_listall will use token stored in register_result
    listall_result = channels.channels_listall(register_result['token'])

    # create data object channel_id_exists which stores string 'false'
    # this will be changed to 'true' if channel that is supposedly created
    # is found in listall_result
    channel_id_exists = True

    # checks if channel previously created is really created using a for loop to loop
    # through all channels.
    for channel in listall_result['channels']:
        if channel['channel_id'] == create_result['channel_id']:
            channel_id_exists = True

    # checks that channel_id_exists is 'true', if this test fails, function must
    # have gone wrong as channel_id does not exist according to channels_listall
    assert channel_id_exists is True

def test_channels_create_long_name1():
    '''
    since channels_create should raise an InputError exception we can test this by
    creating a channel with a long name
        assumes that auth_register works
    '''

    # remove existing data user clear()
    clear()

    # establish test data with channel_name exceeding 20 characters
    email = 'longnametest@test.com'
    password = 'T3stingP4ssw0rd'
    name_first = 'Channel Long Name'
    name_last = 'Tester'
    channel_name = 'This Is A Long Channel Name'

    # create test user using test data and store results in result
        # this result contains a valid token used in channels_create function call
    result = auth.auth_register(email, password, name_first, name_last)

    # attempt to use channel_name that exceeds 20 characters in channels_create function
        # expect function to raise an InputError
    with pytest.raises(InputError):
        assert channels.channels_create(result['token'], channel_name, True)

def test_channels_create_invalid_token():
    '''
    the following test, tests if an AccessError exception is raised when an
    invalid token is provided for channels_create
    '''

    # remove existing data user clear()
    clear()

    # establish some test data and an invalid token
    invalid_token = -1
    channel_name = 'Invalid Token Test'

    # attempt to use invalid token in channels_create function
        # expect function to raise an AccessError
    with pytest.raises(AccessError):
        assert channels.channels_create(invalid_token, channel_name, True)
