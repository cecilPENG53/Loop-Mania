import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from other import clear
from auth import auth_register
from channels import channels_create
from error import InputError
from datetime import datetime as date, timedelta, timezone
# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")
# url = 'http://127.0.01:1531'

def test_message_pin_1(url):
    # creat user
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()
    #create a channel
    r = requests.post(f"{url}/channels/create", json={"token":user_1['token'], "name":'channel_1',
        "is_public":"true"})
    temp = r.json()
    #send message from channel_1
    channelId_1 = temp['channel_id']
    r = requests.post(f"{url}/message/send", json={"token":user_1['token'], "channel_id":channelId_1,
        "message":"hello world!"})
    temp = r.json()
    
    message_id = temp['message_id']
    assert (message_id == 1)
    #message pin
    r = requests.post(f"{url}/message/pin", json={"token":user_1['token'], "message_id":channelId_1})
    result = r.json()
    assert(result == {})

def test_message_pin_2(url):
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()
    #create a channel
    r = requests.post(f"{url}/channels/create", json={"token":user_1['token'], "name":'channel_1',
        "is_public":"true"})
    r.json()
    
    r = requests.post(f"{url}/message/pin", json={"token":user_1['token'], "message_id":2})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "Message_id is not a valid message"
    assert(striphtml(r) == error_message1)
    
def test_message_pin_3(url):
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()
    #create a channel
    r = requests.post(f"{url}/channels/create", json={"token":user_1['token'], "name":'channel_1',
        "is_public":"true"})
    temp = r.json()
    #send message from channel_1
    channelId_1 = temp['channel_id']
    r = requests.post(f"{url}/message/send", json={"token":user_1['token'], "channel_id":channelId_1,
        "message":"hello world!"})
    temp = r.json()
    
    message_id = temp['message_id']
    assert (message_id == 1)
    
    r = requests.post(f"{url}/message/pin", json={"token":user_1['token'], "message_id":channelId_1})
    r.json()
    
    r = requests.post(f"{url}/message/pin", json={"token":user_1['token'], "message_id":channelId_1})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "Message with ID message_id is already pinned"
    assert(striphtml(r) == error_message1)
    
def test_message_pin_4(url):
    # #create two user
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()

    r = requests.post(f"{url}/auth/register", json={"email":'666588@gamil.com', "password":'123456',
        "name_first":"Zoe", "name_last":"Ma"})
    user_2 = r.json()
    #create a channel
    r = requests.post(f"{url}/channels/create", json={"token":user_1['token'], "name":'channel_1',
        "is_public":"true"})
    temp = r.json()
    #send message from channel_1
    channelId_1 = temp['channel_id']
    r = requests.post(f"{url}/message/send", json={"token":user_1['token'], "channel_id":channelId_1,
        "message":"hello world!"})
    temp = r.json()
    
    message_id = temp['message_id']
    assert (message_id == 1)
    
    r = requests.post(f"{url}/channel/join", json={"token":user_2['token'], "channel_id":channelId_1})
    r.json()
    
    r = requests.post(f"{url}/message/pin", json={"token":user_2['token'], "message_id":channelId_1})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "The authorised user is not an owner"
    assert(striphtml(r) == error_message1)
    
def test_message_pin_5(url):
    # #create two user
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()

    r = requests.post(f"{url}/auth/register", json={"email":'666588@gamil.com', "password":'123456',
        "name_first":"Zoe", "name_last":"Ma"})
    user_2 = r.json()
    #create a channel
    r = requests.post(f"{url}/channels/create", json={"token":user_2['token'], "name":'channel_1',
        "is_public":"true"})
    temp = r.json()
    #send message from channel_1
    channelId_1 = temp['channel_id']
    r = requests.post(f"{url}/message/send", json={"token":user_2['token'], "channel_id":channelId_1,
        "message":"hello world!"})
    temp = r.json()
    
    message_id = temp['message_id']
    assert (message_id == 1)
    
    r = requests.post(f"{url}/message/pin", json={"token":user_1['token'], "message_id":channelId_1})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "The authorised user is not a member of the channel that the message is within"
    assert(striphtml(r) == error_message1)

def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    p = re.compile(r'<.*?>')
    return p.sub('', data)
