from data import * 
from channel import channel_invite, channel_details, channel_messages
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
from datetime import datetime as date
from helper_function import add_message
from message import message_send

def test_message_send():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')

    #send message from channel_1
    message_details = 'Hello World!'

    message_send(user_1['token'], 1, "I love python")
    #InputError when any of:Message is more than 1000 characters
    with pytest.raises(InputError):
        message_send(user_1['token'], 1, message_details * 1000)

    #AccessError when:  the authorised user has not joined
    #the channel they are trying to post to
    with pytest.raises(AccessError):
        message_send(user_2['token'], 1, message_details)

    channels_create(user_2['token'], 'channel_2', 'true')
    message_send(user_2['token'], 2, "I love python")
    
    message_id  = message_send(user_1['token'], 1, "second message")
    assert (message_id['message_id'] == 3)
