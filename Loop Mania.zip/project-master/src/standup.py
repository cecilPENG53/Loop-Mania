''' file contain standup functions '''

from datetime import datetime, timezone
from data import user_data, channel_data, valid_token
from error import AccessError, InputError
from message import message_send

def standup_start(token, channel_id, length):
    '''starts a standup with of given duration in given channel_id if token is valid'''

    # return {time_finish}
    dt = datetime.utcnow()
    dt = int(dt.replace(tzinfo=timezone.utc).timestamp())
    time_finish = dt+length

    # token check, error raised if token is invalid
    if token not in valid_token:
        raise AccessError('Invalid token')

    # checks channel_id validity, changes 'standup_time_finish' to time_finish if channel_id is valid
    valid_channel = False

    for user in user_data:
        if token == user['token']:
            standup_starter = user['handle_str']

    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            valid_channel = True
            
            # checks for already ongoing standup if channel_id is valid
            # raise error if there is an ongoing standup
            if channel['standup_time_finish'] is not None:
                raise InputError('Channel already has ongoing standup')
            else:
                channel['standup_time_finish'] = time_finish
                channel['standup_starter'] = standup_starter

    # raise error if channel_id is invalid
    if valid_channel is False:
        raise InputError('Invalid Channel ID')

    return {'time_finish': time_finish}

def standup_active(token, channel_id):
    '''returns whether a standup is currently active and the time it finishes'''

    dt = datetime.utcnow()
    dt = int(dt.replace(tzinfo=timezone.utc).timestamp())

    # token check, error raised if token is invalid
    if token not in valid_token:
        raise AccessError('Invalid token')

    is_active = False
    time_finish = None

    # checks channel_id validity
    valid_channel = False
    
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            valid_channel = True

            if channel['standup_time_finish'] is not None:
                # extract 'standup_time_finish' to time_finish
                time_finish = channel['standup_time_finish']

                # check if time_finish is past current time standup
                # if yes, standup is inactive and stored time_finish in channel needs to be removed
                if dt >= time_finish:
                    channel['standup_time_finish'] = None
                    time_finish = None
                    if channel['standup_messages'] is not None:
                        message_send(token, channel_id, channel['standup_messages'])
                        channel['standup_messages'] = None
                        channel['standup_starter'] = None

                # else standup is still active
                else:
                    is_active = True

    # raise error if channel_id is invalid
    if valid_channel is False:
        raise InputError('Invalid Channel ID')

    return {
        'is_active': is_active,
        'time_finish': time_finish
    }

def standup_send(token, channel_id, message):
    '''adds a given message to a buffered stand up queue if a standup is active'''
    
    # check token valid
    if token not in valid_token:
        raise InputError("You are not a valid user")

    # check channel_id valid
    valid_channel = False
    
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            valid_channel = True

    if valid_channel is False:
        raise InputError("This channel is not exist")

    # check message length
    if len(message) > 1000:
        raise InputError("Message length should be less than 1000")

    # check if a member or owner of channel
    valid_member = False

    for users in user_data:
        if token == users['token']:
            u_id = users['u_id']
            message_sender = users['handle_str']

    for channels in channel_data:
        if channel_id == channels['channel_id']:
            for users in channels['users']:
                if u_id == users['u_id']:
                    valid_member = True

    if valid_member is False:
        raise AccessError("You are not a member of this channel")

    # check if standup active
    standup_res = standup_active(token, channel_id)
    if standup_res['is_active'] is False:
        raise InputError("No active standup currently running in this channel")

    # append message to channel_data
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            if channel['standup_messages'] is None:
                channel['standup_messages'] = f'{message_sender}: {message}\n'
            else:
                channel['standup_messages'] += f'{message_sender}: {message}\n'
    
    return {}
