'''
test file for other.clear and other.users_all function
'''

import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json

@pytest.fixture
def url():
    ''' fixture to get URL of server '''

    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

def test_clear_and_users_all(url):
    '''
    test function to test clear function and user_all function from other.py
    '''

    # clear existing data
    r = requests.delete(f'{url}/clear')
    r = r.json()

    # check return from clear
    assert r == {}

    # register a user for validated token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'clear@test.com', 
        'password': 'T3stingP4ssw0rd',
        'name_first': 'Clear',
        'name_last': 'Tester'
    })

    user_detail = r.json()

    # request users_all function to retrieve all user data
    # expect only one user as the rest have been cleared
    r = requests.get(f'{url}/users/all', params={
        'token': user_detail['token']
    })

    users_data = r.json()

    # establish expected outcome of userall function
    expected_users_all = {
        'users': [
            {
                'u_id': user_detail['u_id'],
                'email': 'clear@test.com',
                'name_first': 'Clear',
                'name_last': 'Tester',
                'handle_str': 'cleartester',
            },
        ],
    }

    # assert output from users_all is per expected
    assert users_data == expected_users_all

    r = requests.get(f'{url}/channels/listall', params={
        'token': user_detail['token']
    })

    listall_detail = r.json()

    # establish expected result
    expected_listall = {'channels': []}

    assert listall_detail == expected_listall

def test_http_users_all_invalid_token(url):
    '''
    token error http test for users_all
    expect error raised
    '''

    # clear existing data
    r = requests.delete(f'{url}/clear')

    # request users_all function with invalid token
    r = requests.get(f'{url}/users/all', json={
        'token': -1
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'Invalid token'
    assert striphtml(r) == expected_message

# the following function is obtained from stackoverflow to remove html tags from a given string
# https://stackoverflow.com/questions/3398852/using-python-remove-html-tags-formatting-from-a-string/3398951

def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    p = re.compile(r'<.*?>')
    return p.sub('', data)