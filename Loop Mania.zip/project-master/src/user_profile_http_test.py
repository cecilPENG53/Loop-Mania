import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from other import clear
from random import choice
import string
from channels_http_test import striphtml
from user_profile_test import clearPhoto


'''
Function Name   HTTP method    Parameters      Return type      Exceptions

user/profile    GET           (token, u_id)      { user }       InputError: when  
                                                                any of:User with
[For a valid user, returns information about                    u_id is not a
user_id, email, first name, last name, and                      valid user
handle]                                                            
                                                                       

user/profile    PUT           (token, name_first,   {}          InputError when
/setname                       name_last)                       any of: name_first
                                                                (or name last) is 
[Update the authorised user's first and last                    not between 1 and
name]                                                           50 characters
                                                                inclusively in
                                                                length.
'''

# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

@pytest.fixture
def user(url):
    '''
    take a valid registered user for test
    '''
    user = []

    email = 'sosplzpass@gmail.com'
    name_first = 'Hehe'
    name_last = 'Haha'
    password = 'HISHI378qdgFTY'
    handle = name_first + name_last
    handle_str = handle.lower()

    INFO = {
        'email': email,
        'password': password,
        'name_first': name_first,
        'name_last': name_last
    }    
    
    userValid = requests.post(f'{url}/auth/register', json=INFO)
    userInfo = userValid.json()

    user.append(userInfo['u_id'])   #[0]
    user.append(userInfo['token'])  #[1]
    user.append(email)              #[2]
    user.append(name_first)         #[3]
    user.append(name_last)          #[4]
    user.append(handle_str)         #[5]

    IMG = {
        'token': user[1],               #valid token
        'img_url': 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg',
                                        #valid image url (jpg)
        'x_start': 300,                 #valid data (</<= max size)
        'y_start': 0,
        'x_end': 600,
        'y_end': 300
    }

    requests.post(f'{url}/user/profile/uploadphoto', json=IMG)
    resp = requests.get(url + "/user_data")
    user_data = json.loads(resp.text)

    for users in user_data:
        if user[0] == users['u_id']:
            user.append(users['profile_img_url']) #[6]

    return user

@pytest.fixture
def name():
    '''
    take a random name (up to 51 chars) for test
    '''
    return ''.join([choice(string.ascii_letters) for i in range(51)])


def test_http_profile_valid(url, user):
    
    #test profile information with a valid user

    IN = {
        'token': user[1],            #valid token
        'u_id': user[0]              #valid user
    }

    OUT = {
        'u_id': user[0],
        'email': user[2],
        'name_first': user[3],
        'name_last': user[4],
        'handle_str': user[5],
        'profile_img_url': user[6]
    }
    
    pass_message(url, 1, IN, OUT)

def test_http_profile_invalid_uid(url, user):

    #test profile information with an invalid user (token)

    IN = {
        'token': user[1]+user[1],    #invalid token
        'u_id': user[0]              #valid u_id
    }

    error_message(url, 1, IN)

def test_http_profile_invalid_token(url, user):

    #test profile information with an invalid user (u_id)

    IN = {
        'token': user[1],            #valid token
        'u_id': user[0]+1            #invalid u_id
    }

    error_message(url, 1, IN)

def test_http_profile_setname_valid(url, user):

    #test profile setname with a suitable name length

    IN = {
        'token': user[1],               #valid token
        'name_first': 'Sos',            #valid new first name
        'name_last': 'Fighting'         #valid new last name
    }

    OUT = {}

    pass_message(url, 2, IN, OUT)

def test_http_profile_setname_invalid_empty(url, user):

    #test profile setname with empty insert, length < 1

    EMPTY1 = {
        'token': user[1],
        'name_first': '',               #invalid new first name (empty, len < 1)
        'name_last': 'Fighting'
    }

    error_message(url, 2, EMPTY1)

    EMPTY2 = {
        'token': user[1],
        'name_first': 'Sos',
        'name_last': ''                 #invalid new last name (empty, len < 1)
    }
    
    error_message(url, 2, EMPTY2)

    EMPTY3 = {
        'token': user[1],
        'name_first': '',               #invalid new first name (empty, len < 1)
        'name_last': ''                 #invalid new last name (empty, len < 1)
    }

    error_message(url, 2, EMPTY3)

def test_http_profile_setname_invalid_length(url, user, name):

    #test profile setname with length > 50

    RANDOM1 = {
        'token': user[1],
        'name_first': name,             #invalid new first name (len > 50)
        'name_last': 'Fighting'
    }

    error_message(url, 2, RANDOM1)

    RANDOM2 = {
        'token': user[1],
        'name_first': 'Sos',
        'name_last': name               #invalid new last name (len > 50)
    }

    error_message(url, 2, RANDOM2)

    RANDOM3 = {
        'token': user[1],
        'name_first': name,             #invalid new first name (len > 50)
        'name_last': name               #invalid new last name (len > 50)
    }

    error_message(url, 2, RANDOM3)

def test_http_profile_uploadphoto_valid(url, user):

    #test profile uploadphoto with a jpg file and crops with a suitable size

    IN = {
        'token': user[1],               #valid token
        'img_url': 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg',
                                        #valid image url (jpg)
        'x_start': 300,                 #valid data (</<= max size)
        'y_start': 0,
        'x_end': 600,
        'y_end': 300
    }

    OUT = {}

    pass_message(url, 3, IN, OUT)

    clearPhoto()

def test_http_profile_uploadphoto_invalid_type(url, user):

    #test profile uploadphoto with a png file

    PNG = {
        'token': user[1],               #valid token
        'img_url': 'https://live.staticflickr.com/4620/27862477829_597a40656e_o.png',
                                        #invalid image url (png)
        'x_start': 300,                 #valid data (</<= max size)
        'y_start': 0,
        'x_end': 600,
        'y_end': 300
    }
    
    mesg = "Image url uploaded is not a JPG."

    error_message2(url, PNG, mesg)

    clearPhoto()

def test_http_profile_uploadphoto_invalid_crop(url, user):

    #test profile uploadphoto with a png file

    mesg = "Croppping data should be within the dimensions of the image."

    NEGATIVE = {
        'token': user[1],               #valid token
        'img_url': 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg',
                                        #valid image url (jpg)
        'x_start': -300,                 #invalid data (< 0)
        'y_start': -1,
        'x_end': -600,
        'y_end': -300
    }

    error_message2(url, NEGATIVE, mesg)

    BIGSTART = {
        'token': user[1],               #valid token
        'img_url': 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg',
                                        #valid image url (jpg)
        'x_start': 948,                 #invalid data (start == max data (start >= end))
        'y_start': 435,
        'x_end': 600,
        'y_end': 300
    }

    error_message2(url, BIGSTART, mesg)

    BEYOUND = {
        'token': user[1],               #valid token
        'img_url': 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg',
                                        #valid image url (jpg)
        'x_start': 1000,                #invalid data (> max data)
        'y_start': 800,
        'x_end': 1000,
        'y_end': 800
    }

    error_message2(url, BEYOUND, mesg)

    clearPhoto()


def pass_message(url, kind, info, result):
    
    if kind == 1:           #user_profile
        resp = requests.get(url + "/user/profile", params=info)
        assert json.loads(resp.text) == {'user': result}
    elif kind == 2:         #user_profile_setname
        resp = requests.put(url + "/user/profile/setname", json=info)
        assert json.loads(resp.text) == result
    else:           #user_profile_uploadphoto
        resp = requests.post(url + "/user/profile/uploadphoto", json=info)
        assert json.loads(resp.text) == result 

    clear()

def error_message(url, kind, info):

    if kind == 1:   #user_profile
        resp = requests.get(url + "/user/profile", params=info)
        mesg = "You are not a valid user"
    else:           #user_profile_setname
        resp = requests.put(url + "/user/profile/setname", json=info)
        mesg = "First name and last name should be between 1 and 50 characters"
    
    ##test method from channels_http_test
    # assert error code is raised
    assert resp.status_code == 400
    res = resp.json()
    
    # assert error message as expected
    msg = res['message']
    assert striphtml(msg) == mesg

    clear()

def error_message2(url, info, mesg):

    resp = requests.post(url + "/user/profile/uploadphoto", json=info)
    
    ##test method from channels_http_test
    # assert error code is raised
    assert resp.status_code == 400
    res = resp.json()
    
    # assert error message as expected
    msg = res['message']
    assert striphtml(msg) == mesg

    clear()

def userImg(url, token, u_id):

    IMG = {
        'token': token,                 #valid token
        'img_url': 'https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/into-the-unknown-scene.jpg',
                                        #valid image url (jpg)
        'x_start': 300,                 #valid data (</<= max size)
        'y_start': 0,
        'x_end': 600,
        'y_end': 300
    }

    requests.post(f'{url}/user/profile/uploadphoto', json=IMG)
    resp = requests.get(url + "/user_data")
    user_data = json.loads(resp.text)

    for users in user_data:
        if u_id == users['u_id']:
            profile_img_url = users['profile_img_url']

    return profile_img_url