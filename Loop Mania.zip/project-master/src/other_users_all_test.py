'''
functionality test file for users_all from other
'''

import pytest
from other import clear, users_all
from auth import auth_register
from error import AccessError

def test_users_all():
    '''
    test functionality of users_all
    '''

    # remove existing data user clear()
    clear()

    # establish data objects to use for test
    email = 'user@test.com'
    password = 'T3stingP4ssw0rd'
    name_first = 'User'
    name_last = 'Tester'
    handle = name_first + name_last

    # use established data to register user
    reg_result = auth_register(email, password, name_first, name_last)

    # establish expected outcome based on details used
    # u_id expected to be 1 as data is cleared for test and test user will be first entry
    expected_outcome = {
        'users': [
            {
                'u_id': reg_result['u_id'],
                'email': email,
                'name_first': name_first,
                'name_last': name_last,
                'handle_str': handle.lower(),
            },
        ],
    }

    # obtain actual results using users_all function
    actual_outcome = users_all(reg_result['token'])

    # compare actual output from users_all function to established expected outcome
    assert actual_outcome == expected_outcome

def test_users_all_invalid_token():
    '''
    tests if an AccessError exception is raised when an invalid token is provided for users_all
    '''

    # remove existing data user clear()
    clear()

    # establish an invalid token
    invalid_token = -1

    # attempt to use invalid token in channels_list function
        # expect function to raise an error
    with pytest.raises(AccessError):
        assert users_all(invalid_token)
