'''
test file for other.clear function
'''

import data
from other import clear

def test_clear_user_data():
    '''
    test function to check if user data in database has been cleared
    '''

    clear()
    assert data.user_data == []

def test_clear_channel_data():
    '''
    test function to check if user data in database has been cleared
    '''

    clear()
    assert data.channel_data == []

def test_clear_valid_token():
    '''
    test function to check if user data in database has been cleared
    '''

    clear()
    assert data.valid_token == []
