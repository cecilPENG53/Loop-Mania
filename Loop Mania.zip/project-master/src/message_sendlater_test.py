from data import * 
from channel import channel_invite, channel_details, channel_messages
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
from datetime import datetime as date, timedelta, timezone
from helper_function import add_message, findChannelFromMsgId
from message import message_sendlater, message_send

def test_message_sendlater():
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
    
    #send message from channel_1
    message_details = 'Hello World!'
    time_sent = date.utcnow() + timedelta(minutes=1)
    #time_sent = time_sent.strftime("%y-%m-%d-%H:%M:%S")
    message_id = message_sendlater(user_1['token'], 1, message_details, time_sent)
    #test coreect details 
    curr_channel = findChannelFromMsgId(message_id['message_id'])
    message_list = curr_channel['messages']
    assert (message_list[0]['time_created'] == time_sent.replace(tzinfo=timezone.utc).timestamp())
    assert (message_list[0]['message'] == message_details)

    #Channel ID is not a valid channel
    with pytest.raises(InputError):
        message_sendlater(user_1['token'], 2, message_details, time_sent)

    #Message is more than 1000
    with pytest.raises(InputError):
        message_sendlater(user_1['token'], 1, message_details * 1000, time_sent)
    
    #characters Time sent is a time in the past
    time_sent_error = date.utcnow() - timedelta(minutes=1)
    with pytest.raises(InputError):
        message_sendlater(user_1['token'], 1, message_details, time_sent_error)

    #accesseeorr: when:the authorised user has not joined the channel they are trying to post to
    with pytest.raises(AccessError):
        message_sendlater(user_2['token'], 1, message_details, time_sent)
