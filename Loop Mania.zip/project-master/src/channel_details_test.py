from data import * 
from channel import channel_invite, channel_details
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
def test_channel_details():
    '''
    InputError when any of:Channel ID is not a valid channel
    AccessError whenAuthorised user is not a member of channel with channel_id
    '''
    #reset data
    clear()

    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel //after it applys channels_create FUNCTION!!!!!
    channels_create(user_1['token'], 'channel_1', 'true')
    print(user_data)
    result = channel_details(user_1['token'], 1)
    assert result == {
        'name' : "channel_1",
        'owner_members' : [
            {
            'u_id' : 0,
            'name_first': 'Li',
            'name_last': 'ming'
            },
        ],
        'all_members' : [
            {
            'u_id' : 0,
            'name_first': 'Li',
            'name_last': 'ming'
            }
        ],
    }

    #test Channel ID is not a valid channel
    with pytest.raises(InputError):
        channel_details(user_1['token'], 8)

    with pytest.raises(InputError):
        channel_invite(user_1['token'], 3, user_2['u_id'])

 
    #test AccessError whenAuthorised user is not a member of channel with channel_id
    # channel_invite(user_1['token'], 1, user_2['u_id'])

    with pytest.raises(AccessError):
        channel_details(3, 1)
    with pytest.raises(AccessError):
        channel_details(user_2['token'], 1)
    clear()
#test_channel_details()


