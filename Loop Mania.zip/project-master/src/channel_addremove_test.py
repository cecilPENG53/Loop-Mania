from channel import channel_addowner, channel_removeowner, channel_join
from auth import auth_register
from channels import channels_create
import data
import pytest
from error import InputError
from error import AccessError
from other import clear

'''
Function Name       Parameters    Return type   Exceptions

channel_addowner    (token,       {}            InputError:
[Make user with      channel_id,                Invalid Channel ID;
user id u_id an      u_id)                      uid is already an
owner of this                                   owner of channel
channel]                                        AccessError:
                                                Invalid authorised
                                                user (not an owner
                                                of the flockr, or
                                                this channel).
                                                
channel_removeowner (token,       {}            InputError:
[Remove user         channel_id,                Invalid Channel ID;
with user id         u_id)                      uid is not an
u_id an owner                                   owner of channel.
of this channel]                                AccessError:
                                                Invalid authorised
                                                user (not an owner
                                                of the flockr, or
                                                this channel).
'''

# To test valid add/remove owner,
# valid users (including authorised & moved)
# and valid channel are needed.

@pytest.fixture
def values():   #for test
    values = []
    
    #valid authorised user
    
    email1 = 'channeladdtest@123.com'
    password1 = 'SOS12315ABCDE'
    name_first1 = 'Ivy'
    name_last1 = 'Lee'      
    #authorised user register
    userAuthorised = auth_register(email1, password1, name_first1, name_last1)
    
    #take token #[0]
    values.append(userAuthorised['token'])
    #take u_id  #[1]
    values.append(userAuthorised['u_id'])

    #valid moved user (not a member of channel)
    
    email2 = 'channeladdtest@789.com'
    password2 = 'Sdhu326GJSdsk'
    name_first2 = 'Sarah'
    name_last2 = 'Smith'    
    #moved user register
    userMoved = auth_register(email2, password2, name_first2, name_last2)

    #take token #[2]
    values.append(userMoved['token'])
    #take u_id  #[3]    
    values.append(userMoved['u_id'])
    
    #valid channel_id
    
    channel_name = 'First Channel'
    is_public = 'true'    
    #authorised user creates a channel
    token = userAuthorised['token']
    channelCreated = channels_create(token, channel_name, is_public)
    
    #take channel_id #[4]
    values.append(channelCreated['channel_id'])

    #valid moved user (a member of channel)
    
    email3 = 'channeladdtest@119.com'
    password3 = '68ehdFWYGHH32873'
    name_first3 = 'Hello'
    name_last3 = 'World'    
    #moved user register
    userMovedMember = auth_register(email3, password3, name_first3, name_last3)

    #take token #[5]
    values.append(userMovedMember['token'])
    #take u_id  #[6]    
    values.append(userMovedMember['u_id'])

    #join the channel
    channel_join(userMovedMember['token'], channelCreated['channel_id'])


    return values


# Success tests

def test_channel_addremove_valid1(values):
    
    token = values[0]           #valid authorised user
    u_id = values[3]            #valid moved user (not a member of channel)
    channel_id = values[4]      #valid channel
   
    assert channel_addowner(token, channel_id, u_id) == {}
    assert channel_removeowner(token, channel_id, u_id) == {}
    
    clear()

def test_channel_addremove_valid2(values):
    
    token = values[0]           #valid authorised user
    u_id = values[6]            #valid moved user (a member of channel)
    channel_id = values[4]      #valid channel
   
    assert channel_addowner(token, channel_id, u_id) == {}
    assert channel_removeowner(token, channel_id, u_id) == {}
    
    clear()

# Exception tests
# assume AccessError of token goes first, 
# InputErrors and AccessError of ids second (1.channel_id, 2.u_id),

def test_add_except_access_invalid_owner1(values):
    
    token1 = values[2]           #invalid owner of channel, moved user's token
    u_id1 = values[3]            #valid moved user'id
    channel_id1 = values[4]      #valid channel
    
    with pytest.raises(AccessError):# as e1:
        assert channel_addowner(token1, channel_id1, u_id1)
    #assert str(e1.value) == "400 Bad Request: You are not an owner of this channel"

    clear()

def test_add_except_access_invalid_owner2(values):
    
    token2 = values[0]+values[2] #invalid owner of flockr
    u_id2 = values[3]            #valid moved user
    channel_id2 = values[4]      #valid channel
    
    with pytest.raises(AccessError):# as e2:
        assert channel_addowner(token2, channel_id2, u_id2)
    #assert str(e2.value) == "400 Bad Request: You are not a user of flockr"

    clear()

def test_add_except_input_invalid_channelid(values):
    
    token = values[0]           #valid authorised user
    u_id = values[3]            #valid moved user
    channel_id = values[4]+42   #invalid channel, not exist
    
    with pytest.raises(InputError):# as e:
        assert channel_addowner(token, channel_id, u_id) 
    #assert str(e.value) == "400 Bad Request: This channel is not exist"
        
    clear()

def test_add_except_access_uid_notuser(values):
    
    token = values[0]           #valid authorised user
    u_id = values[0]+values[2]  #invalid moved user, not user of flockr
    channel_id = values[4]      #valid channel
    
    with pytest.raises(AccessError):# as e:
        assert channel_addowner(token, channel_id, u_id)
    #assert str(e.value) == "400 Bad Request: This id is not a user of flockr"
        
    clear()

def test_add_except_input_uid_isalready(values):
    
    token = values[0]           #valid authorised user
    u_id = values[1]            #invalid moved user, authorised user's uid
    channel_id = values[4]      #valid channel
    
    with pytest.raises(InputError):# as e:
        assert channel_addowner(token, channel_id, u_id)
    #assert str(e.value) == "400 Bad Request: This user is already an owner of the channel"
        
    clear()


def test_remove_except_access_invalid_owner1(values):
    
    token1 = values[2]           #invalid owner of channel, moved user's token
    u_id1 = values[1]            #valid owner, authorised user's id
    channel_id1 = values[4]      #valid channel
    
    with pytest.raises(AccessError):# as e1:
        assert channel_removeowner(token1, channel_id1, u_id1)
    #assert str(e1.value) == "400 Bad Request: You are not an owner of this channel"

    clear()

def test_remove_except_access_invalid_owner2(values):
    
    token2 = values[0]+values[2] #invalid owner of flockr
    u_id2 = values[1]            #valid owner, authorised user's id
    channel_id2 = values[4]      #valid channel
    
    with pytest.raises(AccessError):# as e2:
        assert channel_removeowner(token2, channel_id2, u_id2)
    #assert str(e2.value) == "400 Bad Request: You are not a user of flockr" 

    clear()

def test_remove_except_input_invalid_channelid(values):
    
    token = values[0]           #valid authorised user
    u_id = values[1]            #valid owner, authorised user's id
    channel_id = values[4]+42   #invalid channel, not exist
    
    with pytest.raises(InputError):# as e:
        assert channel_removeowner(token, channel_id, u_id) 
    #assert str(e.value) == "400 Bad Request: This channel is not exist"
        
    clear()

def test_remove_except_access_uid_notuser(values):
    
    token = values[0]           #valid authorised user
    u_id = values[3]+values[6]  #invalid moved user, not user of flockr
    channel_id = values[4]      #valid channel
    
    with pytest.raises(AccessError):# as e:
        assert channel_addowner(token, channel_id, u_id)
    #assert str(e.value) == "400 Bad Request: This id is not a user of flockr"
        
    clear()

def test_remove_except_input_uid_notyet(values):
    
    token = values[0]           #valid authorised user
    u_id = values[3]            #invalid moved user, not added yet
    channel_id = values[4]      #valid channel
    
    with pytest.raises(InputError):# as e:
        assert channel_removeowner(token, channel_id, u_id)
    #assert str(e.value) == "400 Bad Request: This user is not an owner of the channel yet"

    clear()             