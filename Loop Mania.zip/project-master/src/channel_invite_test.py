from data import * 
from channel import channel_invite
from error import InputError, AccessError
from auth import auth_register
import pytest
from channels import channels_create
from other import clear
from helper_function import find_channel

def test_channel_invite():
    '''
    InputError when any of:
        channel_id does not refer to a valid channel.
        u_id does not refer to a valid user

    AccessError whenthe authorised user is not already a member of the channel
    '''
    #reset data
    clear()

    #create two user
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel
    channels_create(user_1['token'], 'channel_1', 'true')
 
    # #channel_id does not refer to a valid channel.
    with pytest.raises(InputError):
        channel_invite(user_1['token'], 3, user_2['u_id'])

    
    # # #u_id does not refer to a valid user
    with pytest.raises(InputError):
        channel_invite(user_1['token'], 1, 5)

    # # #AccessError
    # # #when the authorised user is not already a member of the channel
    with pytest.raises(AccessError):
        channel_invite(user_2['token'], 1, user_2['u_id'])
    #print(user_data)

    #test the function is true 
    channel_invite(user_1['token'], 1, user_2['u_id'])
    #test user has been in this channel
    with pytest.raises(InputError):
        channel_invite(user_1['token'], 1, user_2['u_id'])
    curr_channel = find_channel(1)
    assert len(curr_channel['users']) == 2
    assert curr_channel['users'] ==[
        
            {'u_id': 0, 'name_first': 'Li', 'name_last': 'ming'},
            {'u_id' : 1, 'name_first': 'Zoe', 'name_last': 'MA'}
        ]
    clear()

    
