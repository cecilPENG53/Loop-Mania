'''
test file for admin_userpermission_change function in other.py
'''

import pytest
import data
from other import clear, admin_userpermission_change
from auth import auth_register
from error import AccessError, InputError

def test_admin_userpermission_change():
    '''
    test normal functionality of admin_userpermission_change
    '''

    # remove existing data user clear()
    clear()

    # establish data objects to use for test
    email_1 = 'user1@test.com'
    email_2 = 'user2@test.com'
    password = 'T3stingP4ssw0rd'
    name_first_1 = 'User One'
    name_first_2 = 'User Two'
    name_last = 'Tester'
    permission_id = 1

    # use established data to register user
    user1_res = auth_register(email_1, password, name_first_1, name_last)
    user2_res = auth_register(email_2, password, name_first_2, name_last)

    # assumes first user to have owner level permission
    admin_userpermission_change(user1_res['token'], user2_res['u_id'], permission_id)

    for user in data.user_data:
        if user['u_id'] == user2_res['u_id']:
            assert user['permission_id'] is permission_id

def test_admin_userpermission_change_invalid_token():
    '''
    tests if an AccessError exception is raised when an invalid token is provided for
    admin_userpermission_change
    '''

    # remove existing data user clear()
    clear()

    # establish an invalid token
    invalid_token = -1

    # these are required but should not matter
    u_id = 2
    permission_id = 1

    # attempt to use invalid token in admin_userpermission_change function
        # expect function to raise an error
    with pytest.raises(AccessError):
        assert admin_userpermission_change(invalid_token, u_id, permission_id)

def test_admin_userpermission_change_invalid_user():
    '''
    tests if an InputError exception is raised when an invalid token is provided for
    admin_userpermission_change
    '''

    # remove existing data user clear()
    clear()

    # establish data objects to use for test
    email = 'user@test.com'
    password = 'T3stingP4ssw0rd'
    name_first = 'User'
    name_last = 'Tester'
    other_user_id = -1
    permission_id = 1

    # use established data to register user
    reg_result = auth_register(email, password, name_first, name_last)

    # attempt to use invalid user_id in admin_userpermission_change function
        # expect function to raise an error
    with pytest.raises(InputError):
        assert admin_userpermission_change(reg_result['token'], other_user_id, permission_id)

def test_admin_userpermission_change_invalid_permission_id():
    '''
    tests if an InputError exception is raised when an invalid token is provided for
    admin_userpermission_change
    '''

    # remove existing data user clear()
    clear()

    # establish invalid permission_id
    permission_id = 0

    # these are needed but should not matter
    token = 1
    u_id = 1

    # attempt to use invalid permission_id in admin_userpermission_change function
        # expect function to raise an error
    with pytest.raises(InputError):
        assert admin_userpermission_change(token, u_id, permission_id)

def test_admin_userpermission_change_insufficient_permission():
    '''
    tests if an AccessError exception is raised when an invalid token is provided for
    admin_userpermission_change
    '''

    # remove existing data user clear()
    clear()

    # establish data objects to use for test
    email_1 = 'user1@test.com'
    email_2 = 'user2@test.com'
    password = 'T3stingP4ssw0rd'
    name_first_1 = 'User One'
    name_first_2 = 'User Two'
    name_last = 'Tester'
    permission_id = 2

    # use established data to register user
    user1_res = auth_register(email_1, password, name_first_1, name_last)
    user2_res = auth_register(email_2, password, name_first_2, name_last)

    # attempt to use invalid token in admin_userpermission_change function
    # expect function to raise an error
    # user1 is first user thus should be owner
    # user2 should be a normal user and not have suffice permissions
    with pytest.raises(AccessError):
        assert admin_userpermission_change(user2_res['token'], user1_res['u_id'], permission_id)
