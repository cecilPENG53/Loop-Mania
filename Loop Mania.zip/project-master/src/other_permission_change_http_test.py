'''
test file for other.admin_userpermission_change function
'''

import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json

@pytest.fixture
def url():
    ''' fixture to get URL of server '''

    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

def test_admin_userpermission_change(url):
    '''
    http test for normal functionality of admin_userpermission_change
    '''

    # clear existing data
    r = requests.delete(f'{url}/clear')

    # establish data objects to use for test
    email_1 = 'user1@test.com'
    email_2 = 'user2@test.com'
    password = 'T3stingP4ssw0rd'
    name_first_1 = 'User One'
    name_first_2 = 'User Two'
    name_last = 'Tester'
    permission_id = 1

    # use established data to register two users
    r = requests.post(f'{url}/auth/register', json={
        'email': email_1, 
        'password': password,
        'name_first': name_first_1,
        'name_last': name_last
    })
    
    user1_res = r.json()

    r = requests.post(f'{url}/auth/register', json={
        'email': email_2, 
        'password': password,
        'name_first': name_first_2,
        'name_last': name_last
    })

    user2_res = r.json()

    # assumes first user to have owner level permission
    r = requests.post(f'{url}/admin/userpermission/change', json={
        'token': user1_res['token'],
        'u_id': user2_res['u_id'],
        'permission_id': permission_id
    })

    r = r.json()

    assert r == {}

def test_admin_userpermission_change_invalid_user(url):
    '''
    http test if an InputError exception is raised when an invalid token is provided for
    admin_userpermission_change
    '''

    # clear existing data
    r = requests.delete(f'{url}/clear')

    # establish data objects to use for test
    email = 'user@test.com'
    password = 'T3stingP4ssw0rd'
    name_first = 'User'
    name_last = 'Tester'
    other_user_id = -1
    permission_id = 1

    # use established data to register user
    r = requests.post(f'{url}/auth/register', json={
        'email': email, 
        'password': password,
        'name_first': name_first,
        'name_last': name_last
    })
    
    user_res = r.json()

    # attempt to use invalid user_id in admin_userpermission_change function
        # expect function to raise an error
    r = requests.post(f'{url}/admin/userpermission/change', json={
         'token': user_res['token'],
         'u_id': other_user_id,
         'permission_id': permission_id
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'Invalid user'
    assert striphtml(r) == expected_message


def test_admin_userpermission_change_invalid_permission_id(url):
    '''
    http test if an InputError exception is raised when an invalid token is provided for
    admin_userpermission_change
    '''

    # clear existing data
    r = requests.delete(f'{url}/clear')

    # establish invalid permission_id
    permission_id = 0

    # these are needed but should not matter
    token = 1
    u_id = 1

    # attempt to use invalid permission_id in admin_userpermission_change function
        # expect function to raise an error
    r = requests.post(f'{url}/admin/userpermission/change', json={
         'token': token,
         'u_id': u_id,
         'permission_id': permission_id
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'Invalid permission type'
    assert striphtml(r) == expected_message

def test_admin_userpermission_change_insufficient_permission(url):
    '''
    http test if an AccessError exception is raised when an invalid token is provided for
    admin_userpermission_change
    '''

    # clear existing data
    r = requests.delete(f'{url}/clear')

    # establish data objects to use for test
    email_1 = 'user1@test.com'
    email_2 = 'user2@test.com'
    password = 'T3stingP4ssw0rd'
    name_first_1 = 'User One'
    name_first_2 = 'User Two'
    name_last = 'Tester'
    permission_id = 2

    # use established data to register two users
    r = requests.post(f'{url}/auth/register', json={
        'email': email_1, 
        'password': password,
        'name_first': name_first_1,
        'name_last': name_last
    })
    
    user1_res = r.json()

    r = requests.post(f'{url}/auth/register', json={
        'email': email_2, 
        'password': password,
        'name_first': name_first_2,
        'name_last': name_last
    })

    user2_res = r.json()

    # attempt to use invalid token in admin_userpermission_change function
    # expect function to raise an error
    # user1 is first user thus should be owner
    # user2 should be a normal user and not have suffice permissions
    r = requests.post(f'{url}/admin/userpermission/change', json={
        'token': user2_res['token'],
        'u_id': user1_res['u_id'],
        'permission_id': permission_id
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'User does not have owner permissions'
    assert striphtml(r) == expected_message

# the following function is obtained from stackoverflow to remove html tags from a given string
# https://stackoverflow.com/questions/3398852/using-python-remove-html-tags-formatting-from-a-string/3398951

def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    p = re.compile(r'<.*?>')
    return p.sub('', data)
