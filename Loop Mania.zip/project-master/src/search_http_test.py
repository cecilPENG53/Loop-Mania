import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from other import clear
from auth import auth_register
from channels import channels_create
from error import InputError

# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")
#url = 'http://127.0.01:1531'

def test_search(url):
    #create a user
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user = r.json()

    # #create a channel
    r = requests.post(f"{url}/channels/create", json={"token":user['token'], "name":'channel_1',
        "is_public":"true"})
    temp = r.json()
    channelId = temp['channel_id']

    #send message
    r = requests.post(f"{url}/message/send", json={"token": user['token'], "channel_id": channelId,
        "message": "first message"})
    r = r.json()

    r = requests.post(f"{url}/message/send", json={"token": user['token'], "channel_id": channelId,
        "message": "second message"})
    r = r.json()

    r = requests.get(f"{url}/search?token="+user['token']+"&query_str=mess")
    temp1 = r.json()    
    assert(len(temp1['messages']) == 2)

    r = requests.get(f"{url}/search?token="+user['token']+"&query_str=p")
    temp2 = r.json()
    assert(len(temp2['messages']) == 0)

    r = requests.get(f"{url}/search?token="+user['token']+"&query_str=''")
    temp3 = r.json()
    assert(len(temp3['messages']) == 0)

    r = requests.get(f"{url}/search?token="+user['token']+"&query_str=second")
    temp4 = r.json()
    assert(len(temp4['messages']) == 1)
    