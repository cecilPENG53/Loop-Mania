''' http test file for standup http functions '''

import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from other import clear
from auth import auth_register
from channels import channels_create
from error import InputError, AccessError
from standup import standup_start, standup_active, standup_send
from data import user_data, channel_data, valid_token
from datetime import datetime, timezone
from channels_http_test import striphtml
from standup_test import get_timestamp, long_message

# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

def test_standup_start(url):
    ''' test basic functionality of startup_start '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # establish data objects to use for test
    email = 'standup@test.com'
    password = 'T3sterP4ssw0rd'
    name_first = 'standup'
    name_last = 'tester'
    channel_name = 'standup test'

    # use established data to register user
    r = requests.post(f'{url}/auth/register', json={
        'email': email, 
        'password': password,
        'name_first': name_first,
        'name_last': name_last
    })

    user_detail = r.json()

    # create channel using validated token
    r = requests.post(f'{url}/channels/create', json={
        'token': user_detail['token'],
        'name': channel_name,
        'is_public': True
    })

    channel_detail = r.json()

    # start standup
    r = requests.post(f'{url}/standup/start', json={
        'token': user_detail['token'],
        'channel_id': channel_detail['channel_id'],
        'length': 1
    })

    time_finish = r.json()

    # get current timestamp and using standup_active to check if standup is currently active
    dt = get_timestamp()
    
    # if timestamp obtained is less than time_finish,
        # check that standup_active result agrees that there is an active standup
        # and wait for timestamp difference
    if dt < time_finish['time_finish']:
        r = requests.get(f'{url}/standup/active', params={
            'token': user_detail['token'],
            'channel_id': channel_detail['channel_id'],
        })
        standup_stat = r.json()
    
        assert standup_stat['is_active'] is True
        sleep(time_finish['time_finish']-dt)
    
    # check that standup is not active/no longer active
    r = requests.get(f'{url}/standup/active', params={
        'token': user_detail['token'],
        'channel_id': channel_detail['channel_id'],
    })
    standup_stat = r.json()

    assert standup_stat['is_active'] is False

def test_standup_start_invalid_token(url):
    ''' test if standup_start raises error an invalid token '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # declare parameters for testing
    invalid_token = "invalid_token~"
    channel_id = 1
    length = 15

    # request standup start function with invalid token
    res = requests.post(f'{url}/standup/start', json={
        'token': invalid_token,
        'channel_id': channel_id,
        'length': length
    })

    # assert error code 400 is raised
    assert res.status_code == 400
    res = res.json()
    res = res['message']

    # assert error message is per expected
    expected_message = 'Invalid token'
    assert striphtml(res) == expected_message

def test_standup_start_invalid_channel_id(url):
    ''' test if standup_start raises error an invalid channel_id '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # register a user for valid token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # declare other parameters for testing
    channel_id = 5000
    length = 15

    # request standup start function with invalid channel_id
    res = requests.post(f'{url}/standup/start', json={
        'token': created_user['token'],
        'channel_id': channel_id,
        'length': length
    })

    # assert error code 400 is raised
    assert res.status_code == 400
    res = res.json()
    res = res['message']

    # assert error message is per expected
    expected_message = 'Invalid Channel ID'
    assert striphtml(res) == expected_message

def test_standup_start_ongoing_standup(url):
    ''' test if standup_start checks if there's an ongoing standup '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # register a user for valid token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    user_detail = r.json()

    # create a channel using valid token
    r = requests.post(f'{url}/channels/create', json={
        'token': user_detail['token'],
        'name': 'standup test',
        'is_public': True
    })

    channel_detail = r.json()

    # declare other parameters for testing
    length = 15

    # request first standup start function
    res = requests.post(f'{url}/standup/start', json={
        'token': user_detail['token'],
        'channel_id': channel_detail['channel_id'],
        'length': length
    })

    # request standup start function again
    res = requests.post(f'{url}/standup/start', json={
        'token': user_detail['token'],
        'channel_id': channel_detail['channel_id'],
        'length': length
    })

    # assert error code 400 is raised
    assert res.status_code == 400
    res = res.json()
    res = res['message']

    # assert error message is per expected
    expected_message = 'Channel already has ongoing standup'
    assert striphtml(res) == expected_message

def test_standup_active(url):
    ''' test basic functionality of standup_active '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # register a user for valid token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # create a channel using valid token
    r = requests.post(f'{url}/channels/create', json={
        'token': created_user['token'],
        'name': 'standup test',
        'is_public': True
    })

    created_channel = r.json()

    print(created_channel)
    # check no active stand up when none is started
    r = requests.get(f'{url}/standup/active', params={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id']
    })
    
    standup_stat = r.json()
    assert standup_stat['is_active'] is False
    assert standup_stat['time_finish'] is None

    # declare other parameters
    length = 1

    # start first standup
    r = requests.post(f'{url}/standup/start', json={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id'],
        'length': length
    })

    time_finish = r.json()

    # check function reflects standup data when there is an active standup
    if get_timestamp() < time_finish['time_finish']:
        r = requests.get(f'{url}/standup/active', params={
            'token': created_user['token'],
            'channel_id': created_channel['channel_id']
        })

        standup_stat = r.json()
        assert standup_stat['is_active'] is True
        assert standup_stat['time_finish'] == time_finish['time_finish']

        # sleep for standup to be over
        sleep(time_finish['time_finish']-get_timestamp())
    
    # check that function reflect correct standup data after standup is over
    r = requests.get(f'{url}/standup/active', params={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id']
    })

    standup_stat = r.json()
    assert standup_stat['is_active'] is False
    assert standup_stat['time_finish'] is None

def test_standup_active_invalid_token(url):
    ''' test if standup_active raises error an invalid token '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # declare parameters for testing
    invalid_token = "invalid_token~"
    channel_id = 1

    # request standup active function with invalid token
    r = requests.get(f'{url}/standup/active', params={
        'token': invalid_token,
        'channel_id': channel_id,
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'Invalid token'
    assert striphtml(r) == expected_message

def test_standup_active_invalid_channel_id(url):
    ''' test if standup_active raises error an invalid channel_id '''

    # clear existing data
    requests.delete(f'{url}/clear')

    # register a user for valid token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # declare other parameters for testing
    channel_id = 5000

    # check that InputError is raised when invalid channel ID is passed
    r = requests.get(f'{url}/standup/active', params={
        'token': created_user['token'],
        'channel_id': channel_id
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'Invalid Channel ID'
    assert striphtml(r) == expected_message

def test_standup_send(url):
    ''' test basic functionality of standup_send '''

    # clear existing data
    requests.delete(f'{url}/clear')

    # valid token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # valid channel id
    r = requests.post(f'{url}/channels/create', json={
        'token': created_user['token'],
        'name': 'standup test',
        'is_public': True
    })

    created_channel = r.json()

    # valid message
    message = 'I am valid!'

    # valid standup
    r = requests.post(f'{url}/standup/start', json={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id'],
        'length': 10
    })

    # valid standup/send attempt
    r = requests.post(f'{url}/standup/send', json={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id'],
        'message': message
    })

    assert r.json() == {}

def test_standup_send_invalid_token(url):
    ''' test if standup_send raises error an invalid token '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # declare parameters for testing
    invalid_token = "invalid_token~"
    channel_id = 1
    message = 'does not matter'

    # request standup send function with invalid token
    r = requests.post(f'{url}/standup/send', json={
        'token': invalid_token,
        'channel_id': channel_id,
        'message': message
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'You are not a valid user'
    assert striphtml(r) == expected_message

def test_standup_send_invalid_channel_id(url):
    ''' test if standup_send raises error an invalid channel_id '''
    
    # clear existing data
    requests.delete(f'{url}/clear')

    # valid user/token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # declare parameters for testing
    channel_id = 5000
    message = 'does not matter'

    # request standup send function with invalid token
    r = requests.post(f'{url}/standup/send', json={
        'token': created_user['token'],
        'channel_id': channel_id,
        'message': message
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'This channel is not exist'
    assert striphtml(r) == expected_message

def test_standup_send_long_message(url):
    ''' test if standup_send raises error for messages longer than 1000 characters '''

    # clear existing data
    requests.delete(f'{url}/clear')

    # valid user/token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # valid channel id
    r = requests.post(f'{url}/channels/create', json={
        'token': created_user['token'],
        'name': 'standup test',
        'is_public': True
    })

    created_channel = r.json()

    message = long_message()

    # request standup send function with invalid token
    r = requests.post(f'{url}/standup/send', json={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id'],
        'message': message
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'Message length should be less than 1000'
    assert striphtml(r) == expected_message

def test_standup_send_inactive_standup(url):
    ''' test if standup_send raises error when there is no ongoing standup '''

    # clear existing data
    requests.delete(f'{url}/clear')

    # valid user/token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # valid channel id
    r = requests.post(f'{url}/channels/create', json={
        'token': created_user['token'],
        'name': 'standup test',
        'is_public': True
    })

    created_channel = r.json()

    message = 'Valid Message'

    # request standup send function with invalid token
    r = requests.post(f'{url}/standup/send', json={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id'],
        'message': message
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'No active standup currently running in this channel'
    assert striphtml(r) == expected_message

def test_standup_send_unauthorised_member(url):
    ''' test if standup_send raises error when user of token is not a member of the channel '''

    # clear existing data
    requests.delete(f'{url}/clear')

    # valid user/token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user = r.json()

    # valid channel id
    r = requests.post(f'{url}/channels/create', json={
        'token': created_user['token'],
        'name': 'standup test',
        'is_public': True
    })

    created_channel = r.json()

    message = 'Valid Message'

    # valid 2nd user/token
    r = requests.post(f'{url}/auth/register', json={
        'email': 'standup2@tester.com',
        'password': 'T3sterP@ssw0rd',
        'name_first': 'standup',
        'name_last': 'tester'
    })

    created_user2 = r.json()

    # valid standup
    r = requests.post(f'{url}/standup/start', json={
        'token': created_user['token'],
        'channel_id': created_channel['channel_id'],
        'length': 10
    })

    # valid standup/send attempt
    r = requests.post(f'{url}/standup/send', json={
        'token': created_user2['token'],
        'channel_id': created_channel['channel_id'],
        'message': message
    })

    # assert error code 400 is raised
    assert r.status_code == 400
    r = r.json()
    r = r['message']

    # assert error message is per expected
    expected_message = 'You are not a member of this channel'
    assert striphtml(r) == expected_message