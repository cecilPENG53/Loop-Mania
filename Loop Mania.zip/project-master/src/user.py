'''
user profile, with functions of display info, setname, setemail, sethandle and uploadphoto
'''
from data import user_data, valid_token
from error import InputError
import string
import re
import urllib.request
import os, os.path
from PIL import Image #install pillow


'''
For a valid user, returns information about their
user_id, email, first name, last name, and handle
'''
def user_profile(token, u_id):

    ##test valid user
    valid_user = 0
    
    #1, valid token
    for v_token in valid_token:
        if token == v_token:
            valid_user += 1
    
    img = False
    #2, valid u_id, take info
    for users in user_data:
        if u_id == users['u_id']:
            valid_user += 1
            email = users['email']
            name_first = users['name_first']
            name_last = users['name_last']
            handle_str = users['handle_str']
            if 'profile_img_url' in users:  #key exists
                img = True
                profile_img_url = users['profile_img_url']

    if valid_user != 2:
           raise InputError("You are not a valid user")
    
    if img is True:
        return {
            'user': {
                'u_id': u_id,
                'email': email,
                'name_first': name_first,
                'name_last': name_last,
                'handle_str': handle_str,
                'profile_img_url': profile_img_url
            }
        }
    else:
        return {
            'user': {
                'u_id': u_id,
                'email': email,
                'name_first': name_first,
                'name_last': name_last,
                'handle_str': handle_str
            }
        }

'''
Update the authorised user's first and last name
'''
def user_profile_setname(token, name_first, name_last):
    '''
    ##test valid user
    valid_user = 0
    # valid token
    for v_token in valid_token:
        if token == v_token:
            valid_user += 1
    '''
    name_first = str(name_first)
    name_last = str(name_last)

    #check length of names
    check = 0

    if name_first and len(name_first) <= 50:
        check += 1
    if name_last and len(name_last) <= 50:
        check += 1

    if check != 2:
        raise InputError("First name and last name should be between 1 and 50 characters")
    
    #update new names
    for users in user_data:
        if token == users['token']:
            users['name_first'] = name_first
            users['name_last'] = name_last

    return {
    }
        
def user_profile_setemail(token, email):
    # check whether email is valid or not
    regex = '^[a-z0-9]+[\\._]?[a-z0-9]+[@]\\w+[.]\\w{2,3}$'
    if not re.search(regex, email):
        raise InputError("Email entered is not a valid email")
    
    # duplicate
    # email = str(email)
    for users in user_data:
        if users['email'] == email:
            raise InputError("Email address is already being used by another user")
    
    # uodate email
    for users in user_data:
        if token == users['token']:
            users['email'] = email
            
    return {
    }

def user_profile_sethandle(token, handle_str):
    # length limitation (3<=len<=20)
    handle_len = len(handle_str)
    if handle_len<3 or handle_len>20:
        raise InputError("handle_str must be between 3 and 20 characters")
    
    # duplicate
    for users in user_data:
        if users['handle_str'] == handle_str:
            raise InputError("Handle is already used by another user")
        
    # uodate handle_str
    for users in user_data:
        if token == users['token']:
            users['handle_str'] = handle_str
            
    return {
    }


''' moved to server.py
Given a URL of an image on the internet, 
crops the image within bounds (x_start, y_start)
and (x_end, y_end). Position (0,0) is the top left.

def user_profile_uploadphoto(token, img_url, x_start, y_start, x_end, y_end):

    # check if valid JPG image url

    #regex = 

    if not re.search(regex, img_url):
        raise InputError("Image url uploaded is not a JPG.")

    # create a new local folder for image saving and cropping

    curr_dir = os.getcwd()
    new_dir = os.path.join(curr_dir, r'photo')
    if not os.path.exists(new_dir):
        os.makedirs(new_dir)
    
    # save image to photo folder with counting number
    
    count = 0
    for name in os.listdir(new_dir):
        if os.path.isfile(os.path.join(new_dir, name)):
            count += 1
    count += 1

    img_name = f'{count}.jpg'
    img_path = os.path.join(new_dir, img_name)
    urllib.request.urlretrieve(img_url, img_path)

    # get image size, check with x and y

    im = Image.open(img_path)
    width = im.width
    height = im.height

    x1 = int(x_start)
    x2 = int(x_end)
    y1 = int(y_start)
    y2 = int(y_end)

    # if negative numbers
    if x1 < 0 or y1 < 0 or x2 < 0 or y2 < 0:
        raise InputError("Croppping data should be within the dimensions of the image.")
    
    # if beyond dimensions
    if x1 >= width or y1 >= height or x2 > width or y2 > height:
        raise InputError("Croppping data should be within the dimensions of the image.")
    
    # crop image
    try:
        img_crop = im.crop((x1, y1, x2, y2))
    except:
        raise InputError("Croppping data should be within the dimensions of the image.")
    else:
        img_crop.save(img_path)

    return{
    }
'''