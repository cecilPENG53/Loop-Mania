import sys
from json import dumps
from flask import Flask, request, send_from_directory
from flask_cors import CORS
from error import InputError
import json
import pickle
import string
from data import user_data, channel_data, valid_token
from auth import auth_login, auth_logout, auth_register, auth_passwordreset_request, auth_passwordreset_reset
from channel import channel_invite, channel_details, channel_leave, channel_join, channel_addowner, channel_removeowner, channel_messages
from channels import channels_create, channels_list, channels_listall
from other import clear, users_all, admin_userpermission_change, search
from user import user_profile, user_profile_setname, user_profile_setemail, user_profile_sethandle #, user_profile_uploadphoto
from message import message_send, message_remove, message_edit, message_sendlater, message_react, message_unreact, message_pin, message_unpin
from helper_function import find_message, sent_mail, get_reset_code
from standup import standup_start, standup_active, standup_send
import re
import urllib.request
import os
from PIL import Image #install pillow

def defaultHandler(err):
    response = err.get_response()
    print('response', err, err.get_response())
    response.data = dumps({
        "code": err.code,
        "name": "System Error",
        "message": err.get_description(),
    })
    response.content_type = 'application/json'
    return response

APP = Flask(__name__)
CORS(APP)

APP.config['TRAP_HTTP_EXCEPTIONS'] = True
APP.register_error_handler(Exception, defaultHandler)


clear()

# Example

@APP.route("/echo", methods=['GET'])
def echo():
    data = request.args.get('data')
    if data == 'echo':
   	    raise InputError(description='Cannot echo "echo"')
    return dumps({
        'data': data
    })
 
@APP.route("/example", methods=['Get'])
def example():
    result = user_data
    return dumps(result)
    # return "hello"

@APP.route("/channel_data", methods=['GET'])
def getChannelData():
    return dumps(channel_data)

@APP.route("/test", methods=['GET'])
def test():
    result = request.args.get('token')
    return dumps(result)

@APP.route("/user_data", methods=['GET'])
def getUserData():
    return dumps(user_data)


# Interface

'''Auth'''

@APP.route('/getRestCode', methods = ['POST'])
def getRestCode_http():
    data = request.get_json()
    result = get_reset_code(data['email'])
    return dumps(result)  


@APP.route('/auth/login', methods = ['POST'])
def login():
    """ return token and u_id """
    data = request.get_json()
    result = auth_login(data['email'], data['password'])
    return dumps(result)

@APP.route('/auth/logout', methods = ['POST'])
def logout():
    """ return a bool type "is_success" """
    data = request.get_json()
    result = auth_logout(data['token'])
    return dumps(result)

@APP.route('/auth/register', methods = ['POST'])
def register():
    """ return token and u_id """
    data = request.get_json()
    result = auth_register(data['email'], data['password'],
                      data['name_first'], data['name_last'])
    return dumps(result)

@APP.route('/auth/passwordreset/request', methods = ['POST'])
def http_password_request():
    """ senting reset code return empty dic """
    data = request.get_json()
    auth_passwordreset_request(data['email'])
    #print(user_data)
    reset_code = get_reset_code(data['email'])
    #sent_mail(data['email'], reset_code)
    print(reset_code)
    
    return dumps({})

@APP.route('/auth/passwordreset/reset', methods = ['POST'])
def reset():
    """ return empty dic, change user's password """
    data = request.get_json()
    result = auth_passwordreset_reset(data['reset_code'], data['new_password'])
    return dumps(result)
  


'''Channel'''

@APP.route("/channel/invite", methods=['POST'])
def invite():
    data = request.get_json()
    result = channel_invite(data['token'], data['channel_id'], data['u_id'])
    return dumps(result)

@APP.route("/channel/details", methods=['GET'])
def details():
    token = request.args.get('token')
    channel_id = int(request.args.get('channel_id'))
    result = channel_details(token, channel_id)
    return dumps(result)

@APP.route("/channel/messages", methods=['GET'])
def http_channel_messages():

    """
    {message,start,end}
    """
    token = request.args.get('token')
    channel_id = int(request.args.get('channel_id'))
    start = int(request.args.get('start'))
    result = channel_messages(token, channel_id, start)
    return dumps(result)



@APP.route("/channel/leave", methods=['POST'])
def leave():
    data = request.get_json()
    result = channel_leave(data['token'], data['channel_id'])
    return dumps(result)
    
@APP.route("/channel/join", methods=['POST'])
def join():
    data = request.get_json()
    result = channel_join(data['token'], data['channel_id'])
    return dumps(result)
    
#make a valid user an owner of a valid channel
@APP.route("/channel/addowner", methods=['POST'])
def http_channel_addowner():

    data = request.get_json()
    token = data['token']
    channel_id = data['channel_id']
    u_id = data['u_id']    

    result = channel_addowner(token, channel_id, u_id)
    return dumps(result)

#remove a valid user an owner of a valid channel
@APP.route("/channel/removeowner", methods=['POST'])
def http_channel_removeowner():
    
    data = request.get_json()
    token = data['token']
    channel_id = data['channel_id']
    u_id = data['u_id']    

    result = channel_removeowner(token, channel_id, u_id)
    return dumps(result)


'''Channels'''

#channels_list
@APP.route("/channels/list", methods=['GET'])
def http_channels_list():
    '''
    http function for channels_list
    '''

    # data = request.get_json()
    # for token in valid_token:
    #     if token == data['token']:
    #         data['token'] = token

    # result = channels_list(data['token'])

    # return dumps(result)
    token = request.args.get('token')
    result = channels_list(token)
    return dumps(result)

#channels_listall
@APP.route("/channels/listall", methods=['GET'])
def http_channels_listall():
    '''
    http function for channels_listall
    '''

    # data = request.get_json()
    # for token in valid_token:
    #     if token == data['token']:
    #         data['token'] = token

    # result = channels_listall(data['token'])

    # return dumps(result)

    token = request.args.get('token')
    result = channels_listall(token)
    return dumps(result)

#channels_create
@APP.route("/channels/create", methods=['POST'])
def http_channels_create():
    '''
    http function for channels_create
    '''

    data = request.get_json()
    for token in valid_token:
        if token == data['token']:
            data['token'] = token

    result = channels_create(data['token'], data['name'], data['is_public'])

    return dumps(result)  


'''Message'''

@APP.route("/message/send", methods=['POST'])
def http_message_send():
    data = request.get_json()
    result = message_send(data['token'], data['channel_id'], data['message'])
    return dumps(result)

@APP.route("/message/remove", methods=['DELETE'])
def http_message_remove():
    data = request.get_json()
    result = message_remove(data['token'], data['message_id'])
    return dumps(result)

@APP.route('/message/edit', methods = ['PUT'])
def http_message_edit():
    """ return empty dic, edit a msg """
    data = request.get_json()
    result = message_edit(data['token'], data['message_id'],
                  data['message'])
    return dumps(result)

@APP.route('/message/sendlater', methods=['POST'])
def http_message_sendlater():
    """
    return message_id
    """
    data = request.get_json()
    result = message_sendlater(data['token'], data['channel_id'], data['message'], data['time_sent'])
    return dumps(result)

@APP.route('/message/react', methods=['POST'])
def http_message_react():
    """
    return {}
    """
    data = request.get_json()
    result = message_react(data['token'], data['message_id'], data['react_id'])
    return dumps(result)

@APP.route('/message/unreact', methods=['POST'])
def http_message_unreact():
    """
    return {}
    """
    data = request.get_json()
    result = message_unreact(data['token'], data['message_id'], data['react_id'])
    return dumps(result)


@APP.route('/message/pin', methods=['POST'])
def http_message_pin():
    """
    return {}
    """
    data = request.get_json()
    result = message_pin(data['token'], data['message_id'])
    return dumps(result)
    
@APP.route('/message/unpin', methods=['POST'])
def http_message_unpin():
    """
    return {}
    """
    data = request.get_json()
    result = message_unpin(data['token'], data['message_id'])
    return dumps(result)

'''User'''

#display personal information for a valid user
@APP.route("/user/profile", methods=['GET'])
def http_user_profile():
    
    token = request.args.get('token') #str type
    u_id = request.args.get('u_id')   #str type
    u_id = int(u_id)         #trans to int type

    result = user_profile(token, u_id)
    return dumps(result)

#allow valid user to reset their first name and last name
@APP.route("/user/profile/setname", methods=['PUT'])
def http_user_profile_setname():
    
    data = request.get_json()
    token = data['token']
    name_first = data['name_first']
    name_last = data['name_last']

    result = user_profile_setname(token, name_first, name_last)
    return dumps(result)

@APP.route("/user/profile/setemail", methods=['PUT'])
def setemail():
    data = request.get_json()
    result = user_profile_setemail(data['token'], data['email'])
    return dumps(result)
    
@APP.route("/user/profile/sethandle", methods=['PUT'])
def sethandle():
    data = request.get_json()
    result = user_profile_sethandle(data['token'], data['handle_str'])
    return dumps(result)

@APP.route("/user/profile/uploadphoto", methods=['POST'])
def http_user_profile_uploadphoto():
    
    data = request.get_json()
    token = data['token']
    img_url = data['img_url']
    x_start = data['x_start']
    y_start = data['y_start']
    x_end = data['x_end']
    y_end = data['y_end']

    #result = user_profile_uploadphoto(token, img_url, x_start, y_start, x_end, y_end)
    # check if valid JPG image url

    regex = r'^https?\:[/|\w|.|\s|-]*\.jpe?g$'

    if not re.search(regex, img_url):
        raise InputError("Image url uploaded is not a JPG.")

    # create a new local folder for image saving and cropping

    curr_dir = os.getcwd()
    new_dir = os.path.join(curr_dir, r'photo')
    if not os.path.exists(new_dir):
        os.makedirs(new_dir)
    
    # save image to photo folder with counting number
    
    count = 0
    for name in os.listdir(new_dir):
        if os.path.isfile(os.path.join(new_dir, name)):
            count += 1
    count += 1

    img_name = f'{count}.jpg'
    img_path = os.path.join(new_dir, img_name)
    urllib.request.urlretrieve(img_url, img_path)

    # get image size, check with x and y

    im = Image.open(img_path)
    width = im.width
    height = im.height

    x1 = int(x_start)
    x2 = int(x_end)
    y1 = int(y_start)
    y2 = int(y_end)

    # if negative numbers
    if x1 < 0 or y1 < 0 or x2 < 0 or y2 < 0:
        raise InputError("Croppping data should be within the dimensions of the image.")
    
    # if beyond dimensions
    if x1 >= width or y1 >= height or x2 > width or y2 > height:
        raise InputError("Croppping data should be within the dimensions of the image.")
    
    # crop image
    try:
        img_crop = im.crop((x1, y1, x2, y2))
    except:
        raise InputError("Croppping data should be within the dimensions of the image.")
    else:
        img_crop.save(img_path)
        # backend url
        profile_img_url = request.url_root + f'photo/{img_name}'

        # update img url
        for users in user_data:
            if token == users['token']:
                users['profile_img_url'] = profile_img_url

    return{
    }
    
    #return dumps(result)

@APP.route("/photo/<path:imgname>")
def send_img(imgname):
    return send_from_directory('/photo/', imgname)


'''Users'''

#other.users_all
@APP.route("/users/all", methods=['GET'])
def http_users_all():
    '''
    http function for other.users_all
    '''

    # data = request.get_json()
    # for token in valid_token:
    #     if token == data['token']:
    #         data['token'] = token
    # result = users_all(data['token'])

    # return dumps(result)
    # token = request.args.get('token')
    # for token in valid_token:
    #     if token == token_get:
    #         token_get = token
    # result = users_all(token_get)
    # return dumps(result)

    token = request.args.get('token')
    result = users_all(token)
    return dumps(result)

'''Admin'''

#other.admin_userpermission_change
@APP.route("/admin/userpermission/change", methods=['POST'])
def http_admin_userpermission_change():
    '''
    http function for other.admin_userpermission_change
    '''
    data = request.get_json()
    for token in valid_token:
        if token == data['token']:
            data['token'] = token
    result = admin_userpermission_change(data['token'], data['u_id'], data['permission_id'])

    return dumps(result)


'''Search'''

@APP.route('/search', methods = ['GET'])
def other_search():
    """ return messages """
    token = request.args.get('token')
    query_str = request.args.get('query_str')
    result = search(token, query_str)
    return dumps(result)

'''Clear'''

#other.clear
@APP.route("/clear", methods=['DELETE'])
def http_clear():
    '''
    http function for other.clear
    '''

    result = clear()

    return dumps(result)
    
'''Find message'''
@APP.route("/findMessage", methods=['POST'])
def http_find_message():
    data = request.get_json()
    result = find_message(data['message_id'])
    return dumps(result)  

@APP.route("/standup/start", methods=['POST'])
def http_standup_start():
    '''http function for standup_start'''
    data = request.get_json()
    result = standup_start(data['token'], data['channel_id'], data['length'])
    return dumps(result)

@APP.route("/standup/active", methods=['GET'])
def http_standup_active():
    '''http function for standup_active'''
    token = request.args.get('token')
    channel_id = int(request.args.get('channel_id'))

    result = standup_active(token, channel_id)
    return dumps(result)

@APP.route("/standup/send", methods=['POST'])
def http_standup_send():
    '''http function for standup_send'''
    data = request.get_json()
    result = standup_send(data['token'], int(data['channel_id']), data['message'])
    return dumps(result)

if __name__ == "__main__":
    APP.run(port=0) # Do not edit this port
