Auth: 

1. for login part, when users register first and give their email and password, they are supposed to login successfully unless they enter the wrong password 

2. If the email contains incorrect characters, or it has already been registered by another user, this email will be invalid then. 

3. for logout part, when users register first, they will login automatically. Then, if they want to logout, it will be success.  

4. However, if the user login, then logout and logout again, it returns false since the token is invalid when the user logout first time 

5. for register part, when the first user registered, we create a new account and return a new token for authentication in their session 

6. when email that user entered is used by another user of the password entered is less than six characters, the user is not able to register 

7. if the first name of last name that user entered is not between 1 to 50 characters in length, the register is not successful too. 

 

Channel: 

1. first should check the number is valid  

2. check the invite channel is valid 

3. the invited user and owner are in list of channel?s user 

4. ensuring user in list of channel?s user and channel?s owner when creating channel 

5. When adding a user to be a new owner of a channel, if the user is not a member of this channel yet, then this new owner will become a channel member at the same time. 

6. Removing a user from owners of a channel will not remove the user a member from this channel. 

7. If the channel is not valid, users should not leave from this channel. 

8. If authorised user is not a member of channel, cannot operate the leave function. 

9. Follow-up should be considered that the last user leave from the channel, then this channel should be removed. 

10. If the channel is not valid, users should not join this channel. 

11. If the channel is not private, authorised user can join. 

12. If the channel is private, users only can join by invitation. 

13. Only a valid login user (who is a channel owner), a valid moved user (may be one person, who is not an owner of this channel) and a valid channel id work for adding owners to a channel. 

14. Only a valid login user (who is a channel owner), a valid moved user (may be one person, who is an owner of this channel) and a valid channel id work for removing owners from a channel. 

15.the type of  u_id and channel_id are integer, and should be positive.  

 

Channels: 

1. Channel name can be zero characters, i.e. no channel name 

2. Channel name cannot exceed 20 characters 

3. The user associated with the token, used to create a channel, will be added as an owner and a user at point of creation 

 

Token: 

1. Token will be email addresses 

2. Since email addresses are stored as strings, token will never be an integer 