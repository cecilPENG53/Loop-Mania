from data import * 
from error import InputError, AccessError
import pytest
from channel import channel_invite
from channels import channels_create
from auth import auth_register
from other import clear
from helper_function import find_message
from message import message_send, message_edit

def test_message_edit1():
    clear()
    # create users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')

    # create channel
    channels_create(user_1['token'], 'channel_1', 'true')
    message_send(user_1['token'], 1, "I love python")

    message_edit(user_1['token'], 1, "new first message")

    edit_message = find_message(1)
    assert(edit_message['messages'] == "new first message")

    clear()
    
def test_message_edit2():
    clear()
    #create users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')
    user_3 = auth_register('10086@gamil.com', '123456', 'Jack', 'MA')
    
    #create channel
    channels_create(user_1['token'], 'channel_1', 'true')
    
    channel_invite(user_1['token'], 1, user_2['u_id'])
    message_send(user_2['token'], 1, "first message")
    
    message_edit(user_1['token'], 1, "new first message")
    edit_message1 = find_message(1)
    assert(edit_message1['messages'] == "new first message")

    message_edit(user_2['token'], 1, "second new first message")
    edit_message2 = find_message(1)
    assert(edit_message2['messages'] == "second new first message")
    
    # a normal member who doesn't send message wants to edit it
    with pytest.raises(AccessError):
        message_edit(user_3['token'], 1, "not possible")

    # a member in channel but not the owner who doesn't send message wants to edit it
    channel_invite(user_1['token'], 1, user_3['u_id'])
    with pytest.raises(AccessError):
        message_edit(user_3['token'], 1, "not possible")

    # now member 3 is a admin
    message_edit(user_1['token'], 1, "final message")
    edit_message3 = find_message(1)
    assert(edit_message3['messages'] == "final message")

    clear()
    