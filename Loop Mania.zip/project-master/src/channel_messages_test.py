from data import * 
from channel import channel_invite, channel_details, channel_messages
from error import InputError, AccessError
import pytest
from channels import channels_create
from auth import auth_register
from other import clear
from datetime import datetime as date
from helper_function import add_message

def test_channel_messages():
    '''
    InputError when any of:
        Channel ID is not a valid channel
        start is greater than the total number of messages in the channel

    AccessError whenAuthorised user is not a member of channel with channel_id
    '''
    #reset data
    clear()
    #create two users
    user_1 = auth_register('66404@gamil.com', '123456', 'Li', 'ming')
    user_2 = auth_register('666588@gamil.com', '123456', 'Zoe', 'MA')

    #create a channel //after it applys channels_create FUNCTION!!!!!
    channels_create(user_1['token'], 'channel_1', 'true')
    #manually adds message detail, later using meseeage_send FUNCTION!!!!!!!!!!
    add_message(1, user_1['u_id'], 'Hello world')
    add_message(1, user_1['u_id'], 'i am here')

    
    result = channel_messages(user_1['token'], 1, 0)
    lenth = len(result['messages'])
    #print(result)

    assert lenth == 2
    print(result)
    assert result == {
            'messages': [{'message_id': 1, 'u_id': 0, 'message': 'Hello world'}, 
                        {'message_id': 2, 'u_id': 0, 'message': 'i am here'}], 
            'start': 0, 
            'end': -1
    }
    #print(result)


    # # #test: Channel ID is not a valid channel
    with pytest.raises(InputError):
        channel_messages(user_1['token'], 2, 0)

    # #test: start is greater than the total number of messages in the channel
    with pytest.raises(InputError):
        channel_messages(user_1['token'], 1, 3)

    # #test: when Authorised user is not a member of channel with channel_id    
    with pytest.raises(AccessError):
        channel_messages(user_2['token'], 1, 0)
    clear()
#test_channel_messages()    