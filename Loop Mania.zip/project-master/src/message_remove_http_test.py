import pytest
import re
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
from other import clear
from auth import auth_register
from channels import channels_create
from error import InputError

# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")
#url = 'http://127.0.01:1531'

def test_message_remove(url):
    #create two user
    r = requests.post(f"{url}/auth/register", json={"email":'66404@gamil.com', "password":'123456',
        "name_first":"Li", "name_last":"Ming"})
    user_1 = r.json()

    r = requests.post(f"{url}/auth/register", json={"email":'666588@gamil.com', "password":'123456',
        "name_first":"Zoe", "name_last":"Ma"})
    user_2 = r.json()

    # #create two channel
    r = requests.post(f"{url}/channels/create", json={"token":user_1['token'], "name":'channel_1',
        "is_public":"true"})
    temp = r.json()
    channelId_1 = temp['channel_id']

    r = requests.post(f"{url}/channels/create", json={"token":user_2['token'], "name":'channel_2',
        "is_public":"true"})
    temp = r.json()
    channelId_2 = temp['channel_id']    

    #send message
    r = requests.post(f"{url}/message/send", json={"token":user_1['token'], "channel_id":channelId_1,
        "message":"hello world!"})
    temp = r.json()
    messageId_1 = temp['message_id']

    r = requests.post(f"{url}/message/send", json={"token":user_2['token'], "channel_id":channelId_2,
        "message":"I love python"})
    temp = r.json()
    #messageId_2 = temp['message_id']

    #test error 1
    r = requests.delete(f"{url}/message/remove", json={"token":user_2['token'], "message_id":3})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message1 = "Message (based on ID) no longer exists"
    assert(striphtml(r) == error_message1)

    #test error 2
    r = requests.delete(f"{url}/message/remove", json={"token":user_2['token'], "message_id":messageId_1})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message2 = "Message with message_id wasn't sent by the authorised user making this request or The authorised user is not an owner of this channel or the flockr"
    assert(striphtml(r) == error_message2)

    #create user_3
    r = requests.post(f"{url}/auth/register", json={"email":'z5237777@gamil.com', "password":'unsw123.',
        "name_first":"Hyden", "name_last":"Smith"})
    user_3 = r.json()
    r = requests.post(f"{url}/channel/invite", json={"token":user_1['token'], "channel_id":channelId_1, "u_id":user_3['u_id']})

    #test error 3
    r = requests.delete(f"{url}/message/remove", json={"token":user_3['token'], "message_id":messageId_1})
    assert(r.status_code == 400)
    r = r.json()
    r = r['message']
    error_message3 = "Message with message_id wasn't sent by the authorised user making this request or The authorised user is not an owner of this channel or the flockr"
    assert(striphtml(r) == error_message3)

    #test the message_id is unique
    r = requests.delete(f"{url}/message/remove", json={"token":user_1['token'], "message_id":messageId_1})
    r = requests.post(f"{url}/message/send", json={"token":user_2['token'], "channel_id":channelId_2,
        "message":"this message id is 3"})
    result = r.json()
    assert(result['message_id'] == 3)

def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    p = re.compile(r'<.*?>')
    return p.sub('', data)

#test_message_remove(url)
