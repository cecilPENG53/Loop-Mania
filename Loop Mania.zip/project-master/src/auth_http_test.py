import pytest
import re
import data 
from subprocess import Popen, PIPE
import signal
from time import sleep
import requests
import json
# from data import user_data, channel_data, valid_token
from other import clear
from auth import auth_login, auth_logout, auth_register, auth_passwordreset_request, auth_passwordreset_reset
from error import InputError


# Use this fixture to get the URL of the server. It starts the server for you,
# so you don't need to.
@pytest.fixture
def url():
    url_re = re.compile(r' \* Running on ([^ ]*)')
    server = Popen(["python3", "src/server.py"], stderr=PIPE, stdout=PIPE)
    line = server.stderr.readline()
    local_url = url_re.match(line.decode())
    if local_url:
        yield local_url.group(1)
        # Terminate the server
        server.send_signal(signal.SIGINT)
        waited = 0
        while server.poll() is None and waited < 5:
            sleep(0.1)
            waited += 0.1
        if server.poll() is None:
            server.kill()
    else:
        server.kill()
        raise Exception("Couldn't get URL from local server")

#BASIC_URL = 'http://127.0.01:1531'
#url = 'http://127.0.01:1531'


# test for normal login
# when users register first and give there email and passward
# they are suppose to login successfully    
def test_auth_login(url):
    clear()

    user_email = "goodemail@gmail.com"
    password = '123456789'

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first":"hayden", "name_last":"smith"})
    user = r.json()
    user_token = user['token']

    r = requests.post(f"{url}/auth/login", json = {"email": user_email, "password": password})
    temp = r.json()
    
    uid_info = temp["u_id"]
    toekn_info = temp["token"]
    assert(uid_info == 0)
    assert(toekn_info == user_token)

# test for email entered is not a valid email
# we assume that the email which user entered contains uncorrect character
# email they entered should like sampledata@abc.com
# otherwise they are not able to login
def test_auth_login_invalidEmail(url):
    clear()

    user_email = "minglang@gmail.com"
    password = "12345678"
    
    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first":"minglang", "name_last":"xie"})
    r = r.json()

    r = requests.post(f"{url}/auth/login", json = {"email": "minglang_gmail.com", "password": password})
    r = r.json()
    r = r['message']

    error_message = "Email entered is not a valid email"
    assert(striphtml(r) == error_message)

# test for email entered does not belong to a user
# we assume that the email which user entered is not the one they registerd before
# since the email they entered is wrong, users are not able to login
def test_auth_login_notBelongToUser(url):
    clear()

    user_email = "minglang@gmail.com"
    password = "12345678"

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first":"minglang", "name_last":"xie"})
    r = r.json()

    r = requests.post(f"{url}/auth/login", json = {"email": "w17a.credible4@gmail.com", "password": password})
    r = r.json()
    r = r['message']

    error_message = "Email entered doesn't belong to a user"
    assert(striphtml(r) == error_message)

# this is test for password is not correct
# we assume that the password that user entered is not the one they registerd before
# since teh 
def test_auth_login_passwordIncorrect(url): 
    clear()

    user_email = "minglang@gmail.com"
    password = "12345678"

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first":"minglang", "name_last":"xie"})
    r = r.json()

    r = requests.post(f"{url}/auth/login", json = {"email": user_email, "password": "1234567890"})
    r = r.json()
    r = r['message']

    error_message3 = "Username or password incorrect"
    assert(striphtml(r) == error_message3)


# this is test for users can logout successfully
# we assume users register first and the system will login automatically
# when usters logout, it returns true
def test_auth_logout_ture(url):
    clear()

    user_email = 'hayden@gmail.com'
    password = '123456'

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first": 'hayden', "name_last": 'smith'})
    user = r.json()
    
    r = requests.post(f"{url}/auth/logout", json = {'token': user['token']})
    temp = r.json()

    assert (temp == {'is_success': True})


# this is test for users can not logout successfully
# we assume users register first and the system will login automatically
# then users logout, it returns true
# however, if users logout again, it returns false
# since the token has alreadly been invalid
def test_auth_logout_false(url):
    # login, logout, then logout again
    clear()

    r = requests.post(f"{url}/auth/register", json = {"email": 'hayden@gmail.com', "password": '123456',
        "name_first": 'hayden', "name_last": 'smith'})
    user = r.json()

    r = requests.post(f"{url}/auth/logout", json = {'token': user['token']})
    temp1 = r.json()

    assert (temp1 == {'is_success': True})

    r = requests.post(f"{url}/auth/logout", json = {'token': user['token']})
    temp2 = r.json()

    assert (temp2 == {'is_success': False})


# this is test for normal register
# when the first user registered, 
# we create a new account for them and return a new token for authentication in their session
# when the second user registered, 
# the u_id given should be one more the the first user's uid
def test_auth_register(url):
    clear()

    # create first user
    user_email1 = "minglang@gmail.com"
    password1 = "12345678"

    r = requests.post(f"{url}/auth/register", json = {"email": user_email1, "password": password1,
        "name_first":"minglang", "name_last":"xie"})
    user_1 = r.json()

    uid_info1 = user_1['u_id']
    token1 = user_1['token']


    r = requests.post(f"{url}/auth/login", json = {"email": user_email1, "password": password1})
    temp_1 = r.json()
    
    uid_info2 = temp_1['u_id']
    token2 = temp_1['token']
    assert (uid_info1 == uid_info2)
    assert (token1 == token2)

    # create second user
    user_email2 = "wores@gmail.com"
    password2 = "abcd1234"

    r = requests.post(f"{url}/auth/register", json = {"email": user_email2, "password": password2,
        "name_first": "Yun", "name_last": "Li"})
    user_2 = r.json()

    uid_info3 = user_2['u_id']
    token3 = user_2['token']

    r = requests.post(f"{url}/auth/login", json = {"email": user_email2, "password": password2})
    temp_2 = r.json()

    uid_info4 = temp_2['u_id']
    token4 = temp_2['token']
    
    assert (uid_info3 == uid_info4)
    assert (token3 == token4)

# this is test for email entered is not a valid email
# we assume the email that user regiter for is not like the style of sampledata@abc.com
# since the email enterd is invalid, they are not able to regeiter
def test_auth_register_invalidEmail(url):
    clear()

    r = requests.post(f"{url}/auth/register", json = {"email": 'asdadsad', "password": "123456",
        "name_first": 'gaoping', "name_last": "zhang"})
    r = r.json()
    r = r['message']

    error_message = "Invalid Email"
    assert(striphtml(r) == error_message)

# this is test for email address is already being used by another user
# since the email is already been used, this register is invalid
def test_auth_register_emailBeUsed(url):
    clear()

    user_email = "minglang@gmail.com"
    password = "12345678"

    # create first user
    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first":"minglang", "name_last":"xie"})
    r = r.json()

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first":"minglang", "name_last":"xie"})
    r = r.json()
    r = r['message']

    error_message = "Email address is already used bt another user."
    assert(striphtml(r) == error_message)

# this is test for password entered is less than 6 characters long
# since the password they entered is not what we expect
# this register is invalid and will get inputerror
def test_auth_register_invalidPassword(url):
    clear()

    r = requests.post(f"{url}/auth/register", json = {"email": "minglang@gmail.com", "password": "12345",
        "name_first":"minglang", "name_last":"xie"})
    r = r.json()
    r = r['message']

    error_message = "Password should be at least 6 characters long"
    assert(striphtml(r) == error_message)

# this is test for name_first is not between 1 and 50 characters in length
# since the first name they entered is not what we expect
# this register is invalid and will get inputerror
def test_auth_register_incorrectFirstName(url):
    clear()

    r = requests.post(f"{url}/auth/register", json = {"email": "babala@gmail.com", "password": "12345678",
        "name_first": "Y" * 51, "name_last":  "Li"})
    r = r.json()
    r = r['message']

    error_message = "Firstname is needed between 1 and 50 characters."
    assert(striphtml(r) == error_message)

# this is test for name_last is not between 1 and 50 characters in length
# since the last name they entered is not what we expect
# this register is invalid and will get inputerror
def test_auth_register_incorrectLastName(url):
    clear()

    r = requests.post(f"{url}/auth/register", json = {"email": "babala@gmail.com", "password": "12345678",
        "name_first": "Yun", "name_last":  "L" * 51})
    r = r.json()
    r = r['message']

    error_message = "Lastname is needed between 1 and 50 characters."
    assert(striphtml(r) == error_message)


# this is test for passwordreset/reset
# Given a reset code for a user, 
# set that user's new password to the password provided
# unless it raise the error
def test_auth_passwordreset_reset(url):
    clear()

    user_email = 'minglang@gmail.com'
    password = '12345678'

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first": "minglang", "name_last": "xie"})
    user = r.json()
    user_token = user['token']
    
    r = requests.post(f"{url}/auth/passwordreset/request", json = {"email": user_email})
    r = r.json()

    r = requests.post(f"{url}/getRestCode", json = {"email": user_email})
    resetCode = r.json()
    
    r = requests.post(f"{url}/auth/passwordreset/reset", json = {"reset_code": resetCode, "new_password": '87654321'})
    r = r.json()

    r = requests.post(f"{url}/auth/login", json = {"email": user_email, "password": '87654321'})
    temp = r.json()
    print(temp)
    uid_info = temp["u_id"]
    toekn_info = temp["token"]

    #check whether we had login successfully
    assert(uid_info == 0)
    assert(toekn_info == user_token)



# this is test for passwordreset/reset
# error is raised since reset_code is not valid reset code
def test_auth_passwordreset_reset_invalidResetCode(url):
    clear()

    user_email = 'minglang@gmail.com'
    password = '12345678'

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first": "minglang", "name_last": "xie"})
    r = r.json()

    r = requests.post(f"{url}/auth/passwordreset/request", json = {"email": user_email})
    r = r.json()
    
    r = requests.post(f"{url}/auth/passwordreset/reset", json = {"reset_code": '123', "new_password": '87654321'})
    r = r.json()
    r = r['message']

    error_message = "reset_code is not a valid reset code"
    assert(striphtml(r) == error_message)

# this is test for passwordreset/reset
# error is raised since password entered is not valid
def test_auth_passwordreset_reset_invalidNewPassword(url):
    clear()

    user_email = 'minglang@gmail.com'
    password = '12345678'

    r = requests.post(f"{url}/auth/register", json = {"email": user_email, "password": password,
        "name_first": "minglang", "name_last": "xie"})
    r = r.json()

    r = requests.post(f"{url}/auth/passwordreset/request", json = {"email": user_email})
    r = r.json()
    
    r = requests.post(f"{url}/getRestCode", json = {"email": user_email})
    resetCode = r.json()
    
    r = requests.post(f"{url}/auth/passwordreset/reset", json = {"reset_code": resetCode, "new_password": '1'})
    r = r.json()
    r = r['message']

    error_message = "Password entered is not a valid password"
    assert(striphtml(r) == error_message)


def striphtml(data):
    '''
    function that removes html tags from a given string and returns its text form
    '''
    p = re.compile(r'<.*?>')
    return p.sub('', data)
