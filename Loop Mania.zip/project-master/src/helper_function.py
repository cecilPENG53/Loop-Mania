from data import * 
from error import InputError, AccessError
import pytest
from datetime import datetime as date
import smtplib

def add_message(channel_id, u_id, messages):
    curr_channel = {}
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            curr_channel = channel
    
    message_id = len(curr_channel['messages']) + 1
    
    curr_channel['messages'].append(
        
        {
            'message_id': message_id,
            'u_id' : u_id,
            'message' : messages,
        }
         
    )


#find channel and return details of channel
def find_channel(channel_id):
    channel_list = {}
    for channel in channel_data:
        if channel['channel_id'] == channel_id:
            channel_list = channel
    if channel_list == {} :
        return False
    else:
        return channel_list

#get the user from token
def getUserId(token):
    userId = -1
    for id_user in user_data:
        if id_user['token'] == token:
            userId = id_user['u_id']
            break
    return userId

def is_InChannel(channel, u_id):
    for id_user in channel['users']:
        if id_user['u_id'] == u_id:
            return True
    return False

def generateMsgId():
    # i = 1
    # for channel in channel_data:
    #     i += len(channel['messages'])
    # return i
    i = 1
    for channel in channel_data:
        i += len(channel['messages'])
    if i == 1 :
        return i
    i = 0
    for channel in channel_data:
        for messageId in channel['messages']:
            if messageId['message_id'] > i:
                i = messageId['message_id']
    return i + 1
                
                

def find_message(message_id):
    for channel in channel_data:
        for messageId in channel['messages']:
            if messageId['message_id'] == message_id:
                return messageId
    return {}

def findChannelFromMsgId(message_id):
     for channel in channel_data:
        for messageId in channel['messages']:
            if messageId['message_id'] == message_id:
                return channel
   
def is_InOwnerChannel(channel, u_id):
    for id_user in channel['owners']:
        if id_user['u_id'] == u_id:
            return True
    return False

def get_reset_code(email):
    for user in user_data:
        if user['email'] == email:
            resetCode = user['reset_code']
    return resetCode

def sent_mail(reciever, resetcode):
    """ senting reset code """
    # check 587 if this doesn't work
    mail = smtplib.SMTP('smtp.gmail.com', 587)
    mail.ehlo()
    mail.starttls()
    # email has been set up with these credentials
    mail.login('zeranqiu779@gmail.com', "taoyancomp1531")
    mail.sendmail('zeranqiu779@gmail.com', reciever, resetcode)
    
    mail.close()
#sent_mail("cecil.peng33@gamil.com", "asdfghj")

