Teamwork and Reflection

    Group meeting
1.    First meeting: start at 25 September (Friday), 20:00 +8GMT
In this meeting, we create branches together. Then, reading and analyzing the instruction of project together to make members understand this group task clearly. After checking the due date of iteration 1, we assign each function and it corresponds test. 
2.    Second meeting: start at 26 September (Saturday), 20:00 +8GMT
The aim for this meeting is the clarification of data storage of project. We check the format of our data storage and structure to ensure the consistent in our group. We create and merge data.py to master, in this way also trying the merge request together. Then, we do data.py stores data from other functions in other files. and clarifying and understanding the usage of data.py.
3.    Third meeting: start at 27 September (Sunday), 20:00 +8GMT
We do process update on current work, and uploading some files which are completed to each branches. Then, clarifying black box testing. Make sure the next time of file integration is on lab time.
Any questions during the process will be discussed in the WeChat group in time.

    Time clue
25/09/2020 � start projection with group meeting
27/09/2020 � first time of integrating some files
30/09/2020 � almost files are integrated
01/10/2020 � start to write assumptions
03/10/2020 � all files are integrated and merged to master, assumptions are also integrated
04/10/2020 � last check for iteration 1: details and required files

    Reflection 
 So far, team members get along very well, and communication between team members is timely. Regarding work assignments, we have made minor adjustments in consideration of the group members�tasks in other courses this term. In the next iteration, we will also consider external factors like this to improve work efficiency and quality. In addition, we think that the multi-person collaborative project proposed by tutor in the tutorial is a good idea and should be tried in the next iteration. In the process of brainstorming, work efficiency can be effectively improved, and errors can be found and corrected among team members in time. In this way, the quality of work is also improved accordingly. The important point is that we should strengthen communication with tutor when we find a problem and cannot solve it by ourselves to ensure that the problem is solved in time and does not affect the process. After iteration 1, we need to further check the details of the tasks that may not be aware of based on this evaluation, and set group goals to improve the next tasks.

